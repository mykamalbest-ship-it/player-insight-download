
(()=>{
if(window.__PPA_ANALYZE__)return;
const MONEY=new Intl.NumberFormat('uk-UA',{minimumFractionDigits:0,maximumFractionDigits:2});
const pad=n=>String(n).padStart(2,'0');

function parseDate(t){
  const m=String(t||'').trim().match(/^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})$/);
  if(!m)return null;
  return new Date(+m[1],+m[2]-1,+m[3],+m[4],+m[5],+m[6]);
}
function parseMoney(t){
  const n=Number(String(t??'').replace(/\u00a0/g,' ').replace(/\s+/g,'').replace(',','.').replace(/[^\d.+-]/g,''));
  return Number.isFinite(n)?n:NaN;
}
function fmtDate(d){
  return d instanceof Date&&!isNaN(d)
    ?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
    :'—';
}
function gameName(s){
  if(!s)return '—';
  return s.replace(/[-_]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function safeJson(s){
  try{return JSON.parse(s)}catch{return null}
}


const ppaYield=()=>new Promise(resolve=>{
  if(typeof requestIdleCallback==='function'){
    requestIdleCallback(()=>resolve(),{timeout:80});
  }else{
    setTimeout(resolve,0);
  }
});

async function rowsAsync(root=document,chunkSize=250){
  const out=[];
  const trs=[...root.querySelectorAll('tr.input,tr.bet,tr.win,tr.withdrawal_approved')];

  for(let start=0;start<trs.length;start+=chunkSize){
    const end=Math.min(start+chunkSize,trs.length);
    for(let i=start;i<end;i++){
      const tr=trs[i];
      const td=[...tr.querySelectorAll(':scope > td')];
      if(td.length<7)continue;
      const date=parseDate(td[0]?.textContent);
      if(!date)continue;

      const type=tr.classList.contains('input')?'deposit'
        :tr.classList.contains('bet')?'bet'
        :tr.classList.contains('win')?'win'
        :'withdrawal';

      const details=(td[9]?.textContent||'').trim();
      const detailsJson=safeJson(details);
      const actionId=(td[11]?.textContent||'').trim();
      const secondaryId=(td[12]?.textContent||'').trim();
      const lastId=(td[13]?.textContent||'').trim();

      let depositId='';
      if(type==='deposit'){
        const m=details.match(/Ввод\s+средств\s*№\s*(\d+)/i);
        depositId=m?.[1]||lastId||'';
      }

      out.push({
        type,date,
        provider:(td[1]?.textContent||'').trim(),
        game:(td[3]?.textContent||'').trim(),
        amount:parseMoney(td[5]?.textContent),
        balance:parseMoney(td[6]?.textContent),
        depositId,
        actionId,
        secondaryId,
        parentActionId:detailsJson?.parent_action?.id||'',
        details,
        detailsJson
      });
    }
    // Give rendering/input back to Chrome every ~250 rows.
    if(end<trs.length)await ppaYield();
  }
  out.sort((a,b)=>a.date-b.date);
  return out;
}

function rows(root=document){
  const a=[];
  root.querySelectorAll('tr.input,tr.bet,tr.win,tr.withdrawal_approved').forEach(tr=>{
    const td=[...tr.querySelectorAll(':scope > td')];
    if(td.length<7)return;
    const date=parseDate(td[0]?.textContent);
    if(!date)return;

    let type=tr.classList.contains('input')?'deposit'
      :tr.classList.contains('bet')?'bet'
      :tr.classList.contains('win')?'win'
      :'withdrawal';

    const details=(td[9]?.textContent||'').trim();
    const detailsJson=safeJson(details);
    const actionId=(td[11]?.textContent||'').trim();
    const secondaryId=(td[12]?.textContent||'').trim();
    const lastId=(td[13]?.textContent||'').trim();

    let depositId='';
    if(type==='deposit'){
      const m=details.match(/Ввод\s+средств\s*№\s*(\d+)/i);
      depositId=m?.[1]||lastId||'';
    }

    const parentActionId=detailsJson?.parent_action?.id || '';

    a.push({
      type,date,
      provider:(td[1]?.textContent||'').trim(),
      game:(td[3]?.textContent||'').trim(),
      amount:parseMoney(td[5]?.textContent),
      balance:parseMoney(td[6]?.textContent),
      depositId,
      actionId,
      secondaryId,
      parentActionId,
      details,
      detailsJson
    });
  });
  return a.sort((x,y)=>x.date-y.date);
}


function ppaPeriodBounds(days){
  const end=new Date();
  const start=new Date(end);
  if(Number(days)===0) start.setHours(0,0,0,0);
  else { start.setDate(start.getDate()-Math.max(1,Number(days))); start.setHours(0,0,0,0); }
  return {start,end};
}
function ppaFilterRowsToPeriod(list,days){
  const {start,end}=ppaPeriodBounds(days);
  return {rows:(list||[]).filter(r=>r?.date instanceof Date && r.date>=start && r.date<=end),start,end};
}

// ===== Global Balance Journal collector (v2.5.8) =====
// Stable UI from v2.5.4 + isolated page loader.
// The admin changes ЖБ pages with a full window.location navigation.
// To reproduce that exact browser behaviour without moving the operator,
// Player Insight loads page 2, 3, ... into a hidden same-origin iframe.
// This keeps the admin's normal cookies/session/navigation behaviour and
// leaves the visible ЖБ page untouched.

function ppaJournalPager(root=document){
  const sels=[...root.querySelectorAll('select')];
  let best=null,bestScore=-1;
  for(const sel of sels){
    const opts=[...sel.options].map(o=>({
      n:Number(String(o.textContent||'').trim()),
      value:String(o.value||'').trim()
    })).filter(x=>Number.isFinite(x.n) && x.value);
    if(opts.length<2)continue;
    const balanceHits=opts.filter(x=>/\/players\/playersItems\/balanceLog\/\d+\/?/i.test(x.value)).length;
    const nums=[...new Set(opts.map(x=>x.n))].sort((a,b)=>a-b);
    let seq=0;
    for(let i=0;i<nums.length;i++){if(nums[i]===i+1)seq++;else break;}
    const score=balanceHits*1000+seq*10+opts.length;
    if(score>bestScore){best=sel;bestScore=score;}
  }
  return best;
}

function ppaMergeJournalRows(target,incoming){
  const key=r=>[
    fmtDate(r.date),r.type,r.provider,r.game,
    Number.isFinite(r.amount)?r.amount:'',
    Number.isFinite(r.balance)?r.balance:'',
    r.actionId||'',r.secondaryId||'',r.parentActionId||'',r.depositId||'',r.details||''
  ].join('¦');
  const seen=new Set(target.map(key));
  for(const r of incoming){
    const k=key(r);
    if(!seen.has(k)){seen.add(k);target.push(r);}
  }
}

function ppaLoadJournalFrame(url, timeout=15000){
  return new Promise((resolve,reject)=>{
    const frame=document.createElement('iframe');
    frame.setAttribute('aria-hidden','true');
    frame.tabIndex=-1;
    frame.style.cssText='position:fixed!important;width:1px!important;height:1px!important;left:-10000px!important;top:-10000px!important;opacity:0!important;pointer-events:none!important;border:0!important;';
    let done=false;
    const finish=(err,doc)=>{
      if(done)return;
      done=true;
      clearTimeout(timer);
      frame.remove();
      err?reject(err):resolve(doc);
    };
    const timer=setTimeout(()=>finish(new Error('тайм-аут завантаження сторінки ЖБ')),timeout);
    frame.onload=()=>{
      try{
        const doc=frame.contentDocument;
        if(!doc || !doc.documentElement)return finish(new Error('iframe не повернув HTML'));
        const href=frame.contentWindow?.location?.href||'';
        if(!/\/players\/playersItems\/balanceLog\//i.test(href)){
          return finish(new Error('адмінка перенаправила запит поза ЖБ'));
        }
        // Snapshot the loaded DOM before removing the iframe.
        const html='<!doctype html>'+doc.documentElement.outerHTML;
        const snapshot=new DOMParser().parseFromString(html,'text/html');
        finish(null,snapshot);
      }catch(e){
        finish(new Error('браузер не дозволив прочитати фонову сторінку ЖБ: '+(e?.message||String(e))));
      }
    };
    frame.onerror=()=>finish(new Error('помилка завантаження фонової сторінки ЖБ'));
    document.documentElement.appendChild(frame);
    frame.src=url;
  });
}



async function ppaFetchJournalRows(url,timeout=12000){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),timeout);
  try{
    const res=await fetch(url,{
      method:'GET',credentials:'same-origin',cache:'no-store',
      redirect:'follow',signal:controller.signal,
      headers:{'Accept':'text/html,application/xhtml+xml'}
    });
    if(!res.ok)throw new Error('HTTP '+res.status);
    const html=await res.text();
    await ppaYield();
    const doc=new DOMParser().parseFromString(html,'text/html');
    if(!doc.querySelector('select option[value*="balanceLog"]') && !doc.querySelector('tr.input,tr.bet,tr.win,tr.withdrawal_approved')){
      throw new Error('fetch не повернув сторінку ЖБ');
    }
    return await rowsAsync(doc,350);
  }finally{clearTimeout(timer);}
}
async function ppaLoadJournalRowsFast(url){
  try{return await ppaFetchJournalRows(url);}
  catch(e){
    console.warn('[Player Insight] fast fetch fallback to iframe',e);
    return await ppaLoadJournalRows(url);
  }
}

function ppaLoadJournalRows(url,timeout=15000){
  return new Promise((resolve,reject)=>{
    const frame=document.createElement('iframe');
    frame.setAttribute('aria-hidden','true');
    frame.tabIndex=-1;
    frame.style.cssText='position:fixed!important;width:1px!important;height:1px!important;left:-10000px!important;top:-10000px!important;opacity:0!important;pointer-events:none!important;border:0!important;';
    let done=false;
    const finish=(err,value)=>{
      if(done)return;
      done=true;
      clearTimeout(timer);
      try{frame.remove()}catch{}
      err?reject(err):resolve(value);
    };
    const timer=setTimeout(()=>finish(new Error('таймаут завантаження сторінки ЖБ')),timeout);

    frame.onload=async()=>{
      try{
        const doc=frame.contentDocument;
        if(!doc?.documentElement)return finish(new Error('iframe не повернув HTML'));
        const href=frame.contentWindow?.location?.href||'';
        if(!/\/players\/playersItems\/balanceLog\//i.test(href)){
          return finish(new Error('адмінка перенаправила запит поза ЖБ'));
        }
        // Parse while iframe is alive. No full-page outerHTML copy and no second DOMParser tree.
        const parsed=await rowsAsync(doc,250);
        finish(null,parsed);
      }catch(e){
        finish(new Error('не вдалося прочитати фонову сторінку ЖБ: '+(e?.message||String(e))));
      }
    };
    frame.onerror=()=>finish(new Error('помилка завантаження фонової сторінки ЖБ'));
    document.documentElement.appendChild(frame);
    frame.src=url;
  });
}

async function ppaCollectJournalDays(days=14,onProgress=null){
  const {start:cutoff}=ppaPeriodBounds(days);
  const pager=ppaJournalPager(document);
  const first=await rowsAsync(document,350);

  if(!pager){
    return {
      rows:first,pages:1,totalPages:1,complete:first.some(r=>r.date<=cutoff),
      error:'Не знайдено перемикач сторінок ЖБ.',diagnostics:[{page:1,rows:first.length}]
    };
  }

  const pageMap=new Map();
  for(const o of [...pager.options]){
    const n=Number(String(o.textContent||'').trim());
    if(!Number.isFinite(n))continue;
    try{
      const u=new URL(String(o.value||''),location.href);
      if(u.origin===location.origin && /\/players\/playersItems\/balanceLog\//i.test(u.pathname))pageMap.set(n,u.href);
    }catch{}
  }

  const pageNumbers=[...pageMap.keys()].sort((a,b)=>a-b);
  const totalPages=pageNumbers.length?Math.max(...pageNumbers):1;
  const currentPage=Number(String(pager.options[pager.selectedIndex]?.textContent||'').trim())||1;
  const all=[],seenKeys=new Set(),diagnostics=[];
  let scanned=0,complete=false,error=null;

  const consume=async(page,part)=>{
    if(!part?.length)throw new Error(`Сторінка ${page} завантажилась, але рядки ЖБ не знайдені.`);
    scanned++;
    for(const rr of part){
      const kk=[
        fmtDate(rr.date),rr.type,rr.provider,rr.game,
        Number.isFinite(rr.amount)?rr.amount:'',
        Number.isFinite(rr.balance)?rr.balance:'',
        rr.actionId||'',rr.secondaryId||'',rr.parentActionId||'',rr.depositId||'',rr.details||''
      ].join('¦');
      if(!seenKeys.has(kk)){seenKeys.add(kk);all.push(rr);}
    }
    const dates=part.map(x=>x?.date).filter(d=>d instanceof Date&&!Number.isNaN(d.getTime())).sort((x,y)=>x-y);
    const oldest=dates[0]||null,newest=dates[dates.length-1]||null;
    diagnostics.push({page,rows:part.length,oldest:fmtDate(oldest),newest:fmtDate(newest)});
    try{onProgress?.({page,scanned,rows:part.length,totalRows:all.length});}catch{}
    await ppaYield();
    return !!(oldest&&oldest<=cutoff);
  };

  // Page 1/current page first.
  try{
    const p1=currentPage===1?first:await ppaLoadJournalRowsFast(pageMap.get(1));
    complete=await consume(1,p1);
  }catch(e){
    error=`Сторінка 1: ${e?.message||String(e)}`;
  }

  // Fetch two pages at a time. This is deliberately bounded for weak laptops.
  for(let n=2;n<=totalPages&&!complete&&!error;n+=2){
    const nums=[n,n+1].filter(x=>x<=totalPages&&pageMap.has(x));
    const results=await Promise.all(nums.map(page=>{
      const task=page===currentPage?rowsAsync(document,350):ppaLoadJournalRowsFast(pageMap.get(page));
      return task.then(rows=>({page,rows}),err=>({page,err}));
    }));
    results.sort((x,y)=>x.page-y.page);
    for(const item of results){
      if(item.err){error=`Сторінка ${item.page}: ${item.err?.message||String(item.err)}`;break;}
      try{
        if(await consume(item.page,item.rows)){complete=true;break;}
      }catch(e){error=e?.message||String(e);break;}
    }
    await ppaYield();
  }

  all.sort((x,y)=>x.date-y.date);
  return {rows:all,pages:scanned||1,totalPages,complete,error,diagnostics};
}


function ppaBindInlinePage2Diagnostic(root){
  const btn=root?.querySelector?.('#ppa-diag-page2');
  const box=root?.querySelector?.('#ppa-diag-result');
  if(!btn||!box||btn.dataset.bound==='1')return;
  btn.dataset.bound='1';
  btn.addEventListener('click',async ev=>{
    ev.preventDefault();ev.stopPropagation();
    btn.disabled=true;
    box.className='';
    box.style.display='block';
    box.textContent='Перевіряю сторінку ЖБ №2...';
    try{
      const d=await ppaDiagnosePage2();
      const lines=[
        `PAGE 2: ${d.ok?'OK':'FAIL'}`,
        `Метод: ${d.method||'—'}`,
        `HTML завантажено: ${d.page2Loaded?'так':'ні'}`,
        `Усі <tr>: ${d.allTr??0}`,
        `Кандидати ЖБ: ${d.candidateTr??0}`,
        `Розпізнано операцій: ${d.parsedRows??0}`,
        `Діапазон: ${d.oldest||'—'} — ${d.newest||'—'}`,
        d.error?`Помилка: ${d.error}`:''
      ].filter(Boolean);
      box.textContent=lines.join('\n');
      box.className=d.ok?'ok':'err';
    }catch(e){
      box.textContent='PAGE 2: FAIL\nПомилка: '+(e?.message||String(e));
      box.className='err';
    }finally{btn.disabled=false;}
  });
}



// Real multi-page ЖБ collection. Uses the exact iframe loader proven by PAGE 2 test.
if(!window.__ppa_14d_delegate__){
  window.__ppa_14d_delegate__=true;
  document.addEventListener('click',async ev=>{
    const btn=ev.target?.closest?.('#ppa-load-14d');
    if(!btn)return;
    ev.preventDefault();ev.stopPropagation();

    const root=btn.closest('#__ppa_overlay__')||document.getElementById('__ppa_overlay__');
    if(!root)return;
    const selectedPeriod=root.dataset?.period||'14';
    const box=root.querySelector?.('#ppa-diag-result')||document.querySelector('#ppa-diag-result');
    btn.disabled=true;
    const oldText=btn.textContent;
    btn.textContent='Збираю...';
    if(box){
      box.className='';
      box.style.display='block';
      box.textContent='Починаю збір ЖБ за 14 днів...';
    }

    try{
      const collected=await ppaCollectJournalDays(14,p=>{
        btn.textContent=`Стор. ${p.page}...`;
        if(box)box.textContent=`Збір ЖБ за 14 днів...\nПрочитано сторінок: ${p.scanned}\nОперацій у пам'яті: ${p.totalRows}`;
      });

      const m=window.__ppa_last_result__?.mult||2;
      const filtered=ppaFilterRowsToPeriod(collected.rows,14);
      const r=analyze(m,filtered.rows);
      r.periodStart=filtered.start;
      r.periodEnd=filtered.end;
      if(!r.ok)throw new Error(r.error||'Аналіз не повернув результат.');

      r.journalPages=collected.pages||1;
      r.journalTotalPages=collected.totalPages||1;
      r.journalComplete=!!collected.complete;
      r.journalFetchError=collected.error||null;
      r.journalDiagnostics=collected.diagnostics||[];
      r.incomplete=!collected.complete;
      r.mult=m;
      window.__ppa_last_result__=r;
      root.dataset.period=selectedPeriod;

      renderBalance(root,r,m);
      setupTabs(root,r,m);
      animateSection(root);

      // renderBalance replaced the result box, find the new one.
      const fresh=root.querySelector?.('#ppa-diag-result');
      if(fresh){
        fresh.style.display='block';
        fresh.className=collected.error?'err':'ok';
        const dates=filtered.rows.map(x=>x.date).filter(Boolean).sort((a,b)=>a-b);
        fresh.textContent=[
          collected.error?'ЗБІР ЗУПИНЕНО':'14 ДНІВ ЗІБРАНО',
          `Сторінок прочитано: ${collected.pages||1}`,
          `Операцій у періоді: ${filtered.rows.length}`,
          `Період аналізу: ${fmtDate(filtered.start)} — ${fmtDate(filtered.end)}`,
          `Фактичні дані: ${dates.length?fmtDate(dates[0]):'—'} — ${dates.length?fmtDate(dates[dates.length-1]):'—'}`,
          collected.error?`Помилка: ${collected.error}`:''
        ].filter(Boolean).join('\n');
      }
    }catch(e){
      console.error('[Player Insight][14D COLLECT]',e);
      if(box){
        box.style.display='block';box.className='err';
        box.textContent='ЗБІР FAIL\n'+(e?.message||String(e));
      }
    }finally{
      btn.disabled=false;
      btn.textContent=oldText;
    }
  },true);
}

// Permanent delegated handler: renderBalance() replaces .body.innerHTML,
// so direct button listeners disappear after tab/period re-renders.
// This listener lives on document and therefore always survives.
if(!window.__ppa_page2_diag_delegate__){
  window.__ppa_page2_diag_delegate__=true;
  document.addEventListener('click',async ev=>{
    const btn=ev.target?.closest?.('#ppa-diag-page2');
    if(!btn)return;
    ev.preventDefault();
    ev.stopPropagation();

    const root=btn.closest('#__ppa_root__')||btn.closest('[data-active-tab]')||document;
    const box=root.querySelector?.('#ppa-diag-result')||document.querySelector('#ppa-diag-result');
    if(!box)return;

    btn.disabled=true;
    box.className='';
    box.style.display='block';
    box.textContent='Перевіряю сторінку ЖБ №2...';

    try{
      const d=await ppaDiagnosePage2();
      box.textContent=[
        `PAGE 2: ${d.ok?'OK':'FAIL'}`,
        `Метод: ${d.method||'—'}`,
        `URL: ${d.targetUrl||'—'}`,
        `HTML завантажено: ${d.page2Loaded?'так':'ні'}`,
        `Усі <tr>: ${d.allTr??0}`,
        `Кандидати ЖБ: ${d.candidateTr??0}`,
        `Розпізнано операцій: ${d.parsedRows??0}`,
        `Діапазон: ${d.oldest||'—'} — ${d.newest||'—'}`,
        d.error?`Помилка: ${d.error}`:''
      ].filter(Boolean).join('\n');
      box.className=d.ok?'ok':'err';
    }catch(e){
      box.textContent='PAGE 2: FAIL\nПомилка: '+(e?.message||String(e));
      box.className='err';
    }finally{
      btn.disabled=false;
    }
  },true);
}

// ===== Page 2 diagnostic (v2.5.9) =====
// Completely isolated from Аналіз ЖБ. It only proves whether the extension can
// load and parse the second balanceLog page in the current authenticated admin session.
async function ppaDiagnosePage2(){
  const result={
    ok:false,
    currentUrl:location.href,
    targetUrl:null,
    method:null,
    page2Loaded:false,
    htmlTitle:null,
    allTr:0,
    candidateTr:0,
    parsedRows:0,
    oldest:null,
    newest:null,
    error:null
  };
  try{
    const pager=ppaJournalPager(document);
    if(!pager)throw new Error('Не знайдено select пагінації ЖБ.');

    const opt2=[...pager.options].find(o=>Number(String(o.textContent||'').trim())===2);
    if(!opt2)throw new Error('У пагінації немає сторінки 2.');

    result.targetUrl=new URL(String(opt2.value||''),location.href).href;
    result.method='hidden same-origin iframe';

    const doc=await ppaLoadJournalFrame(result.targetUrl,15000);
    result.page2Loaded=true;
    result.htmlTitle=doc.title||'';
    result.allTr=doc.querySelectorAll('tr').length;
    result.candidateTr=doc.querySelectorAll('tr.input,tr.bet,tr.win,tr.withdrawal_approved').length;

    const parsed=rows(doc);
    result.parsedRows=parsed.length;
    if(parsed.length){
      result.oldest=fmtDate(parsed[0].date);
      result.newest=fmtDate(parsed[parsed.length-1].date);
    }
    result.ok=parsed.length>0;
    if(!result.ok){
      result.error='Сторінка 2 завантажилась, але поточний парсер не знайшов операцій ЖБ.';
    }
  }catch(e){
    result.error=e?.message||String(e);
  }
  console.log('[Player Insight][PAGE2 DIAG]',result);
  return result;
}
window.__PPA_DIAG_PAGE2__=ppaDiagnosePage2;

function findBetForPeak(allRows, start, peakIndex, peakRow){
  if(!peakRow || peakRow.type!=='win') return null;

  // 1) Найточніше: WIN.parent_action.id -> action id ставки.
  if(peakRow.parentActionId){
    for(let i=peakIndex-1;i>=start;i--){
      const r=allRows[i];
      if(r.type==='bet' && (r.actionId===peakRow.parentActionId || r.secondaryId===peakRow.parentActionId)){
        return r;
      }
    }
  }

  // 2) Резерв: найближча попередня ставка в тій самій грі.
  for(let i=peakIndex-1;i>=start;i--){
    const r=allRows[i];
    if(r.type==='bet' && r.game && r.game===peakRow.game) return r;
  }
  return null;
}



function detectWaves(segmentRows, depositAmount, thresholdMultiplier=2){
  const threshold=depositAmount*thresholdMultiplier;
  const waves=[];
  let active=false;
  let startIndex=-1;
  let peakIndex=-1;

  const findBetForWin=(winIndex)=>{
    const win=segmentRows[winIndex];
    if(!win||win.type!=='win')return null;

    if(win.parentActionId){
      for(let i=winIndex-1;i>=0;i--){
        const r=segmentRows[i];
        if(r.type==='bet' && (r.actionId===win.parentActionId || r.secondaryId===win.parentActionId)){
          return r;
        }
      }
    }

    for(let i=winIndex-1;i>=0;i--){
      const r=segmentRows[i];
      if(r.type==='bet' && r.game && r.game===win.game)return r;
    }
    return null;
  };

  const pushWave=()=>{
    if(peakIndex<0)return;
    const peakRow=segmentRows[peakIndex];
    const betRow=findBetForWin(peakIndex);
    const isTech = isExcludedFromGamesStats ? isExcludedFromGamesStats(peakRow) : false;

    waves.push({
      startTime:segmentRows[startIndex]?.date || peakRow.date,
      peakTime:peakRow.date,
      peakBalance:peakRow.balance,
      ratio:peakRow.balance/depositAmount,
      game:isTech ? '' : (peakRow.game||''),
      provider:isTech ? '' : (peakRow.provider||''),
      winAmount:peakRow.type==='win' ? Math.abs(peakRow.amount||0) : 0,
      betAmount:betRow ? Math.abs(betRow.amount||0) : null,
      technical:isTech
    });
  };

  for(let i=0;i<segmentRows.length;i++){
    const r=segmentRows[i];
    if(!Number.isFinite(r.balance))continue;

    if(!active && r.balance>=threshold){
      active=true;
      startIndex=i;
      peakIndex=i;
      continue;
    }

    if(active){
      if(r.balance>segmentRows[peakIndex].balance)peakIndex=i;

      if(r.balance<threshold){
        pushWave();
        active=false;
        startIndex=-1;
        peakIndex=-1;
      }
    }
  }

  if(active && peakIndex>=0)pushWave();

  return waves;
}

function analyze(mult=2, sourceRows=null){
  const all=(sourceRows||rows()).slice().sort((a,b)=>a.date-b.date);
  if(!all.length)return{ok:false,error:'Не знайдено рядків журналу балансу.'};

  const now=new Date(),cut=new Date(now-14*86400000);
  const r=all.filter(x=>x.date>=cut&&x.date<=now);
  if(!r.length)return{ok:false,error:'Немає завантажених операцій за останні 14 днів.'};

  const idx=r.map((x,i)=>x.type==='deposit'?i:-1).filter(i=>i>=0),eps=[];

  for(let d=0;d<idx.length;d++){
    const s=idx[d],e=d+1<idx.length?idx[d+1]:r.length,dep=r[s],amt=Math.abs(dep.amount);
    if(!(amt>0)||!Number.isFinite(dep.balance))continue;

    const pre=dep.balance-amt,tol=Math.max(10,amt*.05);
    if(pre>tol)continue;

    let peak=dep.balance,pr=dep,peakIndex=s,endBal=dep.balance;
    for(let i=s+1;i<e;i++){
      const x=r[i];
      if(Number.isFinite(x.balance)){
        endBal=x.balance;
        if(x.balance>peak){peak=x.balance;pr=x;peakIndex=i}
      }
    }

    const ratio=peak/amt;
    if(ratio+1e-9<mult)continue;

    const peakBet=findBetForPeak(r,s,peakIndex,pr);
    const betAmount=peakBet?Math.abs(peakBet.amount||0):null;

    const wd=r.slice(s+1,e).filter(x=>x.type==='withdrawal'&&x.date>=pr.date);
    const withdrawn=wd.reduce((z,x)=>z+Math.abs(x.amount||0),0);

    const next=d+1<idx.length?r[idx[d+1]]:null;
    const nextPre=next?next.balance-Math.abs(next.amount):null;
    const lost=!wd.length&&next&&Number.isFinite(nextPre)&&nextPre<=tol;

    const segmentRows=r.slice(s,e);
    const waves=detectWaves(segmentRows,amt,2);
    const lastRow=segmentRows[segmentRows.length-1]||dep;
    const endTime=lastRow?.date||dep.date;
    const crossedDay=endTime && dep.date && (endTime.toDateString()!==dep.date.toDateString());
    const zeroTol=Math.max(1,amt*.01);
    const exhausted=Number.isFinite(endBal) && endBal<=zeroTol;
    let lifecycleStatus='active';
    if(withdrawn>0) lifecycleStatus='withdrawn';
    else if(lost||exhausted) lifecycleStatus='lost';
    else if(next) lifecycleStatus='closed';
    eps.push({
      id:dep.depositId||'—',amt,time:dep.date,depTime:dep.date,pre,peak,peakTime:pr.date,ratio,
      game:pr.game,provider:pr.provider,endBal,withdrawn,withdrawTime:wd[0]?.date||null,lastWithdrawTime:wd[wd.length-1]?.date||null,
      lost:(lost||exhausted),betAmount,waves,endTime,nextDepositTime:next?.date||null,crossedDay,lifecycleStatus
    });
  }

  eps.sort((a,b)=>b.ratio-a.ratio||b.peak-a.peak);
  const depositList=idx.map(i=>({date:r[i].date,amount:Math.abs(r[i].amount||0)}));
  return{ok:true,episodes:eps,count:eps.length,total:r.length,deposits:idx.length,depositList,depositSum:depositList.reduce((s,d)=>s+d.amount,0),oldest:r[0]?.date,incomplete:r[0]?.date>cut};
}



// Локальна база лише для значень, які вдалося підтвердити у джерелі самого провайдера.
// Якщо гри тут немає, UI показує "Немає даних" — нічого не вгадується.
const OFFICIAL_VOLATILITY = {
  "carnival-joker": {
    label: "Середня–висока",
    level: "medium-high",
    source: "Slotmill"
  },
  "books-bulls-deluxe": {
    label: "Висока",
    level: "high",
    source: "GAMOMAT"
  },
  "books-and-bulls-deluxe": {
    label: "Висока",
    level: "high",
    source: "GAMOMAT"
  }
};

function volatilityFor(gameSlug){
  const key=String(gameSlug||'').trim().toLowerCase();
  return OFFICIAL_VOLATILITY[key] || null;
}

function volatilityBadge(v){
  if(!v)return '<span class="vol vol-none">— Немає даних</span>';
  const icon=v.level==='high'?'🔴':v.level==='medium-high'?'🟠':v.level==='medium'?'🟡':v.level==='low'?'🟢':'•';
  return `<span class="vol vol-${v.level}">${icon} ${v.label}</span>`;
}


// Технічні/сайтові активності, які не є реальною грою для рейтингу "Ігри".
// Вони залишаються в ЖБ для коректного розрахунку балансу, але не рахуються як слот.
const GAME_ACTIVITY_EXCLUSIONS = {
  providers: new Set([
    "msjackpot"
  ]),
  games: new Set([
  ])
};

function specialActivitySlug(){
  const host=String(location.hostname||'').toLowerCase();
  if(host==='admin.vegas.ua'||host.endsWith('.vegas.ua')) return 'vegas-heist';
  if(host==='admin.777.ua'||host.endsWith('.777.ua')) return 'club-millionaires';
  return '';
}
function specialActivityLabel(slug){
  return slug==='vegas-heist'?'VEGAS HEIST':'CLUB MILLIONAIRES';
}

function isExcludedFromGamesStats(row){
  const provider=String(row?.provider||'').trim().toLowerCase();
  const game=String(row?.game||'').trim().toLowerCase();
  // Project-specific jackpot activity is shown in "Ігри" as a compact bets-only card.
  if(game===specialActivitySlug()) return false;
  return GAME_ACTIVITY_EXCLUSIONS.providers.has(provider)
    || GAME_ACTIVITY_EXCLUSIONS.games.has(game);
}

function gameStats(){
  const all=rows();
  const now=new Date(),cut=new Date(now-14*86400000);
  const r=all.filter(x=>
    x.date>=cut &&
    x.date<=now &&
    (x.type==='bet'||x.type==='win') &&
    x.game &&
    !isExcludedFromGamesStats(x)
  );
  const map=new Map();
  for(const x of r){
    if(!map.has(x.game))map.set(x.game,{game:x.game,provider:x.provider||'',bets:0,wins:0,wagered:0,won:0,maxBet:0,maxWin:0,last:null});
    const g=map.get(x.game);
    if(x.provider&&!g.provider)g.provider=x.provider;
    if(x.type==='bet'){
      const a=Math.abs(x.amount||0);g.bets++;g.wagered+=a;if(a>g.maxBet)g.maxBet=a;
    }else if(x.type==='win'){
      const a=Math.abs(x.amount||0);g.wins++;g.won+=a;if(a>g.maxWin)g.maxWin=a;
    }
    if(!g.last||x.date>g.last)g.last=x.date;
  }
  const games=[...map.values()].sort((a,b)=>{
    const special=specialActivitySlug();
    const ac=String(a.game||'').trim().toLowerCase()===special;
    const bc=String(b.game||'').trim().toLowerCase()===special;
    if(ac!==bc) return ac?-1:1;
    return b.bets-a.bets||b.wagered-a.wagered;
  });
  const special=specialActivitySlug();
  for(const g of games){
    g.isSpecialActivity=String(g.game||'').trim().toLowerCase()===special;
    // Backward-compatible alias for older rendering code paths.
    g.isClubMillionaires=g.isSpecialActivity;
  }
  const rankedGames=games.filter(g=>!g.isSpecialActivity);
  const totalBets=rankedGames.reduce((s,g)=>s+g.bets,0);
  games.forEach(g=>g.share=g.isSpecialActivity?0:(totalBets?g.bets/totalBets*100:0));
  return{games,totalBets,totalGames:games.length,totalRows:r.length};
}

function tier(x){
  return x>=10?['🔥','x10+','fire']
    :x>=5?['◆','x5+','strong']
    :x>=3?['▲','x3+','good']
    :['●','x2+','base'];
}

function compactX(x){
  if(!Number.isFinite(x)) return '—';
  const rounded=Math.round(x);
  return Math.abs(x-rounded)<0.05 ? String(rounded) : x.toFixed(2).replace('.',',');
}

function copyText(e){
  const game=gameName(e.game);
  const x=compactX(e.ratio);
  const bet=e.betAmount && e.betAmount>0
    ? ` зі ставкою ${MONEY.format(e.betAmount)} грн`
    : '';
  return `Х${x} у грі ${game}${bet} — виграш склав ${MONEY.format(e.peak)} грн`;
}


function setCopiedState(btn, originalText, delay=1400){
  if(!btn)return;
  btn.textContent='✓ Скопійовано';
  btn.classList.add('copy-only-ok');
  setTimeout(()=>{
    btn.textContent=originalText;
    btn.classList.remove('copy-only-ok');
  },delay);
}

function animateSection(root){
  const body=root?.querySelector('.body');
  if(!body)return;
  body.classList.remove('section-enter');
  void body.offsetWidth;
  body.classList.add('section-enter');
  setTimeout(()=>body.classList.remove('section-enter'),220);
}


function ppaPageContext(){
  // Context is determined by the actual admin section first. This keeps the
  // two navigation groups strictly separated on both 777 and Vegas.
  const path=String(location.pathname||'').toLowerCase();
  if(/\/players\/playersitems\/balancelog\//i.test(path))return 'balance';
  if(/\/players\/playersitems\/update\//i.test(path))return 'manager';
  if(ppaIsBalanceJournal())return 'balance';
  if(ppaHasManagerCardData())return 'manager';
  return 'other';
}
function ppaApplyContextUI(root){
  const ctx=ppaPageContext();
  root.dataset.ppaContext=ctx;
  const balanceTabs=new Set(['balance','negative','games','bets']);
  const managerTabs=new Set(['manager','bonuses']);
  root.querySelectorAll('.tabbtn').forEach(btn=>{
    const tab=btn.dataset.tab;
    const visible=(ctx==='balance'&&balanceTabs.has(tab)) || (ctx==='manager'&&managerTabs.has(tab));
    // v3.0.9: CSS for the polished header uses display:inline-flex !important,
    // so a normal inline style cannot hide context-inappropriate tabs.
    // Set the inline property with !important as well.
    btn.style.setProperty('display', visible ? 'inline-flex' : 'none', 'important');
  });
  const sub=root.querySelector('.sub');
  if(sub)sub.textContent=ctx==='manager'?'VIP-менеджер гравця · v3.0.9':'Аналіз за останні 14 днів';
}
function shell(){
  document.getElementById('__ppa_overlay__')?.remove();
  const root=document.createElement('div');
  root.id='__ppa_overlay__';
  root.innerHTML=`<style>#__ppa_overlay__{position:fixed!important;top:10px!important;right:10px!important;left:auto!important;bottom:auto!important;transform:none!important;z-index:2147483647;width:min(470px,calc(100vw - 36px));max-height:calc(100vh - 20px);background:#0b0d12;color:#f7f8fb;border:1px solid #252b36;border-radius:17px;box-shadow:0 24px 80px rgba(0,0,0,.5);font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:hidden}#__ppa_overlay__ *{box-sizing:border-box}#__ppa_overlay__ .head{padding:14px 15px;border-bottom:1px solid #222833;display:flex;justify-content:space-between;align-items:center;background:#10131a}#__ppa_overlay__ .brand{display:flex;align-items:center;gap:10px}#__ppa_overlay__{animation:ppaPanelIn .26s cubic-bezier(.2,.8,.2,1) both}
@keyframes ppaPanelIn{from{opacity:0;transform:translateY(10px) scale(.985)}to{opacity:1;transform:translateY(0) scale(1)}}
#__ppa_overlay__ .card{animation:ppaCardIn .2s ease-out both}
@keyframes ppaCardIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
#__ppa_overlay__ .copy-ok{color:#8fe7a4!important;border-color:#315c3f!important;background:#13251a!important}
#__ppa_overlay__ .body.section-enter{animation:ppaSectionIn .18s ease-out both}
@keyframes ppaSectionIn{from{opacity:.2;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
#__ppa_overlay__ .copy-only-ok{color:#8fe7a4!important;border-color:#315c3f!important;background:#13251a!important}

#__ppa_overlay__ .timeline-btn{border:1px solid #343c49;background:#171c24;color:#d9dee7;border-radius:7px;padding:6px 8px;font-size:10px;cursor:pointer}
#__ppa_overlay__ .timeline-btn:hover{border-color:#725cff;color:#fff}
#__ppa_overlay__ .timeline-wrap{margin-top:10px;border-top:1px solid #303744;padding-top:10px;animation:ppaSectionIn .18s ease-out both}
#__ppa_overlay__ .timeline-title{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px;font-size:10px;color:#9aa4b4}
#__ppa_overlay__ .timeline-close{border:0;background:transparent;color:#8993a4;cursor:pointer;font-size:14px;padding:2px 5px}
#__ppa_overlay__ .tl{position:relative;padding-left:18px}
#__ppa_overlay__ .tl:before{content:"";position:absolute;left:5px;top:7px;bottom:8px;width:2px;background:#2c3340;border-radius:2px}
#__ppa_overlay__ .tl-row{position:relative;padding:0 0 11px 8px}
#__ppa_overlay__ .tl-row:last-child{padding-bottom:2px}
#__ppa_overlay__ .tl-dot{position:absolute;left:-17px;top:4px;width:10px;height:10px;border-radius:50%;background:#667085;border:2px solid #11151c}
#__ppa_overlay__ .tl-row.deposit .tl-dot{background:#7b5cff}
#__ppa_overlay__ .tl-row.peak .tl-dot{background:#79e5a2;box-shadow:0 0 10px rgba(121,229,162,.3)}
#__ppa_overlay__ .tl-row.withdraw .tl-dot{background:#59b8ff}
#__ppa_overlay__ .tl-row.end .tl-dot{background:#ff8d8d}
#__ppa_overlay__ .tl-main{display:flex;justify-content:space-between;gap:8px;align-items:baseline}
#__ppa_overlay__ .tl-label{font-size:10.5px;font-weight:800;color:#e5e9ef}
#__ppa_overlay__ .tl-bal{font-size:11px;font-weight:900;color:#fff;white-space:nowrap}
#__ppa_overlay__ .tl-sub{font-size:9.5px;color:#7f8999;margin-top:2px;line-height:1.35}
#__ppa_overlay__ .tl-peak{color:#8fe7a4}

#__ppa_overlay__ .minbtn{border:0;background:#181d25;color:#9ba5b5;border-radius:7px;padding:4px 8px;font-size:15px;cursor:pointer}
#__ppa_overlay__ .minbtn:hover{color:#fff;background:#222834}
#__ppa_overlay__.ppa-minimized{
  width:58px!important;height:58px!important;min-height:58px!important;max-height:58px!important;
  border-radius:17px!important;overflow:hidden!important;cursor:grab!important;
  box-shadow:0 14px 36px rgba(0,0,0,.42),0 0 0 1px rgba(125,92,255,.22),0 0 24px rgba(113,86,255,.16)!important;
  transition:left .28s cubic-bezier(.2,.8,.2,1),right .28s cubic-bezier(.2,.8,.2,1),top .22s cubic-bezier(.2,.8,.2,1),transform .18s ease,box-shadow .18s ease!important;
  user-select:none!important;touch-action:none!important;
}
#__ppa_overlay__.ppa-minimized:hover{transform:scale(1.045)!important;box-shadow:0 16px 42px rgba(0,0,0,.48),0 0 0 1px rgba(137,108,255,.38),0 0 30px rgba(113,86,255,.25)!important}
#__ppa_overlay__.ppa-minimized.ppa-dragging{cursor:grabbing!important;transition:none!important;transform:scale(1.055)!important}
#__ppa_overlay__.ppa-minimized .head{height:58px!important;padding:10px!important;border:0!important;justify-content:center!important;background:linear-gradient(145deg,#111622,#0d1017)!important}
#__ppa_overlay__.ppa-minimized .brand{display:flex!important;align-items:center!important;justify-content:center!important;gap:0!important}
#__ppa_overlay__.ppa-minimized .brand>div:not(.logo){display:none!important}
#__ppa_overlay__.ppa-minimized .actions,#__ppa_overlay__.ppa-minimized .tabs,#__ppa_overlay__.ppa-minimized .body{display:none!important}
#__ppa_overlay__.ppa-minimized .logo{
  display:grid!important;width:38px!important;height:38px!important;margin:0!important;border-radius:11px!important;
  box-shadow:0 6px 18px rgba(114,92,255,.34),inset 0 0 0 1px rgba(255,255,255,.08)!important;
}
#__ppa_overlay__.ppa-minimized:after{
  content:"";position:absolute;top:22px;width:3px;height:14px;border-radius:4px;background:#826cff;opacity:.9;
}
#__ppa_overlay__.ppa-minimized.ppa-dock-left:after{right:3px}
#__ppa_overlay__.ppa-minimized.ppa-dock-right:after{left:3px}

#__ppa_notice__{
  position:fixed;z-index:2147483646;max-width:270px;padding:10px 12px;
  background:#111620;color:#dfe5ee;border:1px solid #313949;border-radius:11px;
  box-shadow:0 14px 38px rgba(0,0,0,.38),0 0 0 1px rgba(126,97,255,.10);
  font:11px/1.42 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  opacity:0;transform:translateY(5px) scale(.97);pointer-events:none;
  transition:opacity .18s ease,transform .22s cubic-bezier(.2,.8,.2,1);
}
#__ppa_notice__.show{opacity:1;transform:translateY(0) scale(1)}
#__ppa_notice__ .n-title{font-weight:850;color:#fff;margin-bottom:2px}
#__ppa_notice__ .n-text{color:#9ca7b7}
#__ppa_overlay__ .periods{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:9px}
#__ppa_overlay__ .periodbtn{border:1px solid #303744;background:#171b23;color:#929cab;border-radius:7px;padding:5px 8px;font-size:9.5px;font-weight:750;cursor:pointer}
#__ppa_overlay__ .periodbtn.active{background:#6d5dfc;border-color:#6d5dfc;color:#fff}
#__ppa_overlay__ .rangehint{font-size:9.5px;color:#778295;margin-left:auto;white-space:nowrap;align-self:center}

#__ppa_overlay__ .stats.stats-wide .stat{min-width:0;overflow:hidden}
#__ppa_overlay__ .stats.stats-wide .stat b{font-size:16px;line-height:1.15;overflow-wrap:anywhere}
#__ppa_overlay__ .stats.stats-wide .stat span{line-height:1.25}
#__ppa_overlay__ .stats.stats-wide .stat:nth-child(4),#__ppa_overlay__ .stats.stats-wide .stat:nth-child(5){grid-column:span 1}
#__ppa_overlay__ .stats.stats-wide .stat:last-child{grid-column:1 / -1}
#__ppa_overlay__ .periods{flex-wrap:wrap;row-gap:6px}
#__ppa_overlay__ .rangehint{margin-left:0!important;width:100%;text-align:right;padding-right:2px}
#__ppa_overlay__ .tabs{position:sticky;top:0;z-index:18;background:#111523}
#__ppa_overlay__ .periods{position:relative;top:auto;z-index:1;background:transparent;padding:7px 0}
#__ppa_overlay__ .card{transition:transform .16s ease,border-color .16s ease,box-shadow .16s ease}
#__ppa_overlay__ .card:hover{transform:translateY(-1px);border-color:#514c79;box-shadow:0 9px 24px rgba(0,0,0,.18)}
#__ppa_overlay__ .tier.base{color:#aaa4ff}#__ppa_overlay__ .tier.good{color:#9f96ff}#__ppa_overlay__ .tier.strong{color:#c0a8ff}#__ppa_overlay__ .tier.fire{color:#e1bdff}
#__ppa_overlay__ .statuschip{display:inline-flex;padding:4px 7px;border:1px solid #343a4d;border-radius:999px;background:#181d2b;color:#aeb6c9;font-size:10px;font-weight:700;margin-top:6px}
#__ppa_overlay__ .contextbadge{font-size:9px;color:#9da5ba;background:#181d2b;border:1px solid #303649;border-radius:999px;padding:3px 6px;margin-left:6px}
#__ppa_overlay__ .refresh{width:28px;height:28px;border:1px solid #303649;border-radius:8px;background:#151a27;color:#aeb6c9;cursor:pointer;font-size:15px}
#__ppa_overlay__ .refresh.loading{pointer-events:none;animation:ppaSpin .8s linear infinite}
#__ppa_overlay__ .updated{font-size:9px;color:#70798d;white-space:nowrap}
#__ppa_overlay__ .data-note{display:block;margin-top:3px;font-size:8.5px;color:#8f7d58;font-weight:600}
@keyframes ppaSpin{to{transform:rotate(360deg)}}
#__ppa_overlay__ .stat span small{display:block;margin-top:2px;font-size:9px;text-transform:none;color:#7f879a;font-weight:500}
#__ppa_overlay__ .negstat span small{display:block;margin-top:3px;font-size:9px;color:#8f98ac;font-weight:600}
#__ppa_overlay__ .nstat span{display:block;margin-top:5px;color:#d9deea;font-size:10px;font-weight:800;line-height:1.25;letter-spacing:.15px}
#__ppa_overlay__ .nstat span small{display:block;margin-top:6px;font-size:10px;color:#aeb7ca;font-weight:700;line-height:1.25;letter-spacing:0}
#__ppa_overlay__ .nstat .neg-label{display:block!important;margin-top:7px!important;color:#dfe4ee!important;font-size:10.5px!important;font-weight:700!important;line-height:1.3!important;letter-spacing:0!important;text-transform:none!important}
#__ppa_overlay__ .nstat .neg-range{display:block;margin-top:8px;color:#8f99ad;font-size:9.5px;font-weight:600;line-height:1.35}
#__ppa_overlay__ .neg-legend-title{margin:8px 2px 10px;color:#8e97aa;font-size:10px;line-height:1.35}
#__ppa_overlay__ .neg-label{display:block!important;min-height:28px;margin-top:8px!important;color:#dfe4ee!important;font-size:10.5px!important;font-weight:700!important;line-height:1.3!important;text-transform:none!important}
#__ppa_overlay__ .neg-badge{display:inline-flex;margin-top:9px;padding:4px 8px;border-radius:999px;background:rgba(109,93,252,.13);border:1px solid rgba(129,112,255,.35);color:#b9afff;font-size:10px;font-weight:800;line-height:1}
#__ppa_overlay__ .neg-legend-title{display:none!important}
#__ppa_overlay__ .neg-category-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:10px 0 14px}
#__ppa_overlay__ .neg-category-grid>div{min-width:0;min-height:96px;display:flex!important;flex-direction:column;align-items:flex-start}
#__ppa_overlay__ .neg-category-grid .neg-label{min-height:30px!important}
#__ppa_overlay__ .neg-category-grid .neg-badge{margin-top:auto!important}


#__ppa_overlay__ .withdraw-main{display:flex;align-items:baseline;justify-content:space-between;gap:10px}
#__ppa_overlay__ .withdraw-main strong{font-size:12px;color:#aeb7ca;font-weight:700;white-space:nowrap}


#__ppa_overlay__ .peakcompare{margin:-2px 0 10px;padding:7px 10px;border:1px solid #292f40;border-radius:9px;background:#131824;color:#8f98ac;font-size:10px}
#__ppa_overlay__ .peakcompare b{color:#c3cad8;font-weight:700}


#__ppa_overlay__ .empty-state{padding:26px 14px;text-align:center;color:#8d95a9;border:1px dashed #303648;border-radius:12px;background:#151a27}
#__ppa_overlay__ .ppa-journal-flash{animation:ppaJournalFlash 1.7s ease}
@keyframes ppaJournalFlash{20%{outline:3px solid rgba(155,139,255,.72);background-color:rgba(155,139,255,.12)}100%{outline-color:rgba(155,139,255,0)}}

#__ppa_overlay__ .jumpgroup{display:inline-flex;gap:0}
#__ppa_overlay__ .jumpgroup .jumpbtn{border-radius:0;margin:0}
#__ppa_overlay__ .jumpgroup .jumpbtn:first-child{border-radius:7px 0 0 7px}
#__ppa_overlay__ .jumpgroup .jumpbtn:last-child{border-radius:0 7px 7px 0}
#__ppa_overlay__ .jumpgroup .jumpbtn+.jumpbtn{margin-left:-1px}

#__ppa_overlay__ .lastdep{border:1px solid #302b50;background:linear-gradient(180deg,#17152a,#131620);border-radius:11px;padding:9px 10px;margin-bottom:10px}
#__ppa_overlay__ .lastdep-title{font-size:9px;color:#9d8cff;text-transform:uppercase;letter-spacing:.45px;font-weight:850;margin-bottom:5px}
#__ppa_overlay__ .lastdep-main{font-size:13px;font-weight:900;color:#fff}
#__ppa_overlay__ .lastdep-sub{font-size:9.5px;color:#8993a4;margin-top:3px}
#__ppa_overlay__ .jumpbtn{border:1px solid #303744;background:#171b23;color:#cfd5df;border-radius:7px;padding:6px 8px;font-size:10px;cursor:pointer}
#__ppa_overlay__ .jumpbtn:hover{border-color:#6d5dfc;color:#fff}
.__ppa_row_flash__{animation:ppaRowFlash 2.2s ease-out!important;outline:3px solid #7b5cff!important;outline-offset:-2px!important}
@keyframes ppaRowFlash{0%,35%{background:#eee9ff!important;box-shadow:0 0 0 5px rgba(123,92,255,.28)!important}100%{background:inherit;box-shadow:none}}
#__ppa_overlay__ .logo{width:34px;height:34px;border-radius:10px;overflow:hidden;box-shadow:0 6px 18px rgba(114,92,255,.24);background:linear-gradient(135deg,#6c4df4,#8b58ff);display:grid;place-items:center;color:#fff;font-weight:900}#__ppa_overlay__ .logo img{width:100%;height:100%;display:block}#__ppa_overlay__ .insight{color:#8b63ff}#__ppa_overlay__ .title{font-size:14px;font-weight:850}#__ppa_overlay__ .sub{font-size:10.5px;color:#8993a4;margin-top:2px}#__ppa_overlay__ .actions{display:flex;gap:6px}#__ppa_overlay__ .iconbtn{border:1px solid #303744;background:#171b23;color:#dfe4ec;border-radius:8px;padding:6px 9px;cursor:pointer;font-size:11px}#__ppa_overlay__ .close{font-size:18px;padding:2px 8px}#__ppa_overlay__ .body{
  padding:12px 14px 12px 12px;
  overflow:auto;
  max-height:calc(100vh - 85px);
  scrollbar-width:thin;
  scrollbar-color:#665a8f transparent;
}
.body::-webkit-scrollbar{width:7px}
.body::-webkit-scrollbar-track{background:transparent;margin:8px 0}
.body::-webkit-scrollbar-thumb{
  background:linear-gradient(180deg,#51496b,#7561a9);
  border-radius:999px;
  border:2px solid #0b0d12;
  min-height:48px;
}
.body::-webkit-scrollbar-thumb:hover{
  background:linear-gradient(180deg,#6958a2,#8a6dff);
}
.body::-webkit-scrollbar-button{display:none;width:0;height:0}#__ppa_overlay__ .tabs{display:flex;gap:6px}.tabbtn{border:1px solid #303744;background:#171b23;color:#aeb7c5;border-radius:8px;padding:6px 9px;cursor:pointer;font-size:10.5px}.tabbtn.active{background:#6d5dfc;border-color:#6d5dfc;color:#fff;font-weight:800}
.gamesIntro{font-size:11px;color:#929cab;line-height:1.45;margin-bottom:10px}
.negintro{font-size:11px;color:#929cab;line-height:1.45;margin-bottom:10px}
.neggrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}
.negbox{background:#141821;border:1px solid #242b36;border-radius:10px;padding:10px}.negbox b{display:block;font-size:15px;margin-bottom:2px}.negbox span{font-size:9.5px;color:#8e98a8}
.negsection{background:#13171e;border:1px solid #272e39;border-radius:12px;padding:11px;margin-bottom:9px}.negtitle{font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#8f99aa;margin-bottom:7px;font-weight:800}
.negline{font-size:11.5px;line-height:1.45;color:#dfe4eb}.negline b{color:#fff}.negstatus{margin-top:7px;padding:8px 9px;border-radius:8px;font-size:10.5px;font-weight:750}
.negactions{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}
.moment{background:#13171e;border:1px solid #272e39;border-radius:12px;padding:11px;margin-bottom:9px}
.momenthead{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
.momentx{font-size:17px;font-weight:900;color:#8fe7a4}.momentdate{font-size:9.5px;color:#8e98a8}
.momentflow{font-size:16px;font-weight:900;margin:6px 0 8px}.momentmeta{display:grid;grid-template-columns:1fr auto;gap:5px 10px;font-size:10.5px}.momentmeta span:nth-child(odd){color:#8993a4}.momentmeta span:nth-child(even){color:#e0e5ec;font-weight:700;text-align:right}
.momenttag{margin-top:9px;padding:8px 9px;border-radius:8px;font-size:10.5px;font-weight:800}
.momentcopy{margin-top:8px;border:1px solid #303744;background:#191d25;color:#dce1e9;border-radius:7px;padding:6px 8px;font-size:10.5px;cursor:pointer}.negbtn{border:1px solid #303744;background:#191d25;color:#dce1e9;border-radius:7px;padding:6px 8px;font-size:10.5px;cursor:pointer}
.neg-good{background:#12251a;color:#8fe7a4}.neg-bad{background:#2a1719;color:#ff9b9b}.neg-mid{background:#292416;color:#e7ce8d}.gamecard{background:#13171e;border:1px solid #272e39;border-radius:12px;padding:11px;margin-bottom:8px}.gamehead{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.gamename{font-size:13px;font-weight:850;overflow-wrap:anywhere}.gamepos{font-size:11px;color:#8f99aa}.share{font-size:13px;font-weight:850;color:#8fe7a4}.bar{height:5px;background:#242a34;border-radius:999px;overflow:hidden;margin:8px 0 10px}.barin{height:100%;background:linear-gradient(90deg,#6757f7,#9b65ff);border-radius:999px}.gamegrid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.gstat{background:#0f1218;border-radius:8px;padding:7px}.gstat b{display:block;font-size:12px}.gstat span{font-size:9px;color:#8993a4}.gamecopy{margin-top:9px}
.focusbox{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:9px;padding:8px 9px;border-radius:8px;background:#0f1218;border:1px solid #242b36}
.focusleft{font-size:10px;color:#8993a4}.focusright{font-size:10.5px;font-weight:850;text-align:right}
.focus-hot{color:#ff9b9b}.focus-high{color:#ffbe78}.focus-mid{color:#e8d47d}.focus-low{color:#8f99aa}
.copyoperator{margin-left:5px}
.volrow{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:9px;padding:8px 9px;background:#0f1218;border-radius:8px;font-size:10.5px}
.voltitle{color:#8993a4}.vol{font-weight:800}.vol-high{color:#ff9b9b}.vol-medium-high{color:#ffbe78}.vol-medium{color:#f0d77a}.vol-low{color:#8fe7a4}.vol-none{color:#8791a1}.volsrc{font-size:9px;color:#727c8b;margin-top:4px}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:10px}#__ppa_overlay__ .stats.stats-wide{grid-template-columns:repeat(2,minmax(0,1fr))}#__ppa_overlay__ .stat{background:#141821;border:1px solid #242b36;border-radius:10px;padding:9px}#__ppa_overlay__ .stat b{display:block;font-size:16px}#__ppa_overlay__ .stat span{font-size:9.5px;color:#8e98a8}#__ppa_overlay__ .warn{padding:9px 10px;border-radius:9px;background:#2a2416;border:1px solid #514421;color:#e7ce8d;font-size:11px;margin-bottom:10px}#__ppa_overlay__ .filters{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px}#__ppa_overlay__ .filterbtn{border:1px solid #303744;background:#171b23;color:#bfc7d3;border-radius:8px;padding:6px 9px;font-size:10.5px;cursor:pointer}#__ppa_overlay__ .filterbtn.active{background:#6d5dfc;border-color:#6d5dfc;color:#fff;font-weight:800}#__ppa_overlay__ .tools{display:flex;justify-content:space-between;align-items:center;margin:4px 1px 10px}#__ppa_overlay__ .tools span{font-size:11px;color:#8f99aa}#__ppa_overlay__ .sort{background:#141821;color:#e8ebf1;border:1px solid #2b3240;border-radius:8px;padding:6px;font-size:10.5px}#__ppa_overlay__ .card{background:#13171e;border:1px solid #272e39;border-radius:13px;margin-bottom:9px;overflow:hidden}#__ppa_overlay__ .accent{height:3px;background:#6757f7}#__ppa_overlay__ .fire .accent{background:linear-gradient(90deg,#ffb24d,#ff6d5a)}#__ppa_overlay__ .strong .accent{background:linear-gradient(90deg,#b36cff,#745cff)}#__ppa_overlay__ .good .accent{background:linear-gradient(90deg,#58c7ff,#6e73ff)}#__ppa_overlay__ .cardin{padding:11px}#__ppa_overlay__ .tag{font-size:9.5px;color:#9da6b5;text-transform:uppercase;letter-spacing:.55px}#__ppa_overlay__ .hero{display:flex;justify-content:space-between;align-items:baseline;margin:5px 0 10px}#__ppa_overlay__ .money{font-size:17px;font-weight:900}#__ppa_overlay__ .ratio{font-size:18px;font-weight:900;color:#8fe7a4}#__ppa_overlay__ .grid{display:grid;grid-template-columns:112px 1fr;gap:5px 9px;font-size:11.5px}#__ppa_overlay__ .k{color:#8993a4}#__ppa_overlay__ .v{overflow-wrap:anywhere}#__ppa_overlay__ .status{margin-top:9px;padding:8px 9px;border-radius:8px;font-size:11px;font-weight:750}#__ppa_overlay__ .st-ok{background:#12251a;color:#8fe7a4}#__ppa_overlay__ .st-bad{background:#2a1719;color:#ff9b9b}#__ppa_overlay__ .st-mid{background:#292416;color:#e7ce8d}#__ppa_overlay__ .cardfoot{display:flex;gap:6px;margin-top:9px;flex-wrap:wrap}
#__ppa_overlay__ .toolright{display:flex;align-items:center;gap:6px}
#__ppa_overlay__ .compactbtn,#__ppa_overlay__ .contextbtn{border:1px solid #303744;background:#171b23;color:#bfc7d3;border-radius:8px;padding:6px 8px;font-size:10px;cursor:pointer}
#__ppa_overlay__ .afterpeak{margin-top:9px;padding:8px 9px;border:1px solid #282f3b;border-radius:8px;background:#10141b}
#__ppa_overlay__ .afterpeak span{display:block;color:#7f899a;font-size:9px;margin-bottom:3px}
#__ppa_overlay__ .afterpeak b{display:block;color:#cdd3df;font-size:10.5px;line-height:1.35}
#__ppa_overlay__ .contextlinks{display:flex;gap:5px;margin-left:auto}
#__ppa_overlay__ .compact-mode .card .grid,#__ppa_overlay__ .compact-mode .card .status,#__ppa_overlay__ .compact-mode .card .jumpgroup,#__ppa_overlay__ .compact-mode .card .waves,#__ppa_overlay__ .compact-mode .card .wavesbtn{display:none!important}
#__ppa_overlay__ .compact-mode .cardin{padding:9px 10px}
#__ppa_overlay__ .compact-mode .hero{margin:3px 0 6px}
#__ppa_overlay__ .compact-mode .afterpeak{margin-top:5px;padding:6px 8px}
#__ppa_overlay__ .compact-mode .cardfoot{margin-top:6px}
#__ppa_overlay__ .compact-mode .copy{display:none}
#__ppa_overlay__ .gamegrid .x2stat{grid-column:1 / -1}
#__ppa_overlay__ .context-highlight{border-color:#7c68ff!important;box-shadow:0 0 0 2px rgba(124,104,255,.18),0 10px 28px rgba(0,0,0,.25)!important}
#__ppa_overlay__ .moment.context-highlight{transition:border-color .2s,box-shadow .2s}
#__ppa_overlay__ .betsintro{padding:10px 11px;border:1px solid #2b313d;border-radius:10px;background:#11151c;color:#929caf;font-size:10px;line-height:1.45;margin-bottom:10px}
#__ppa_overlay__ .betssummary{display:flex;align-items:baseline;gap:8px;padding:10px 11px;border:1px solid #2b313d;border-radius:10px;background:#151922;margin-bottom:10px}
#__ppa_overlay__ .betssummary b{font-size:22px;color:#f0f2f7} #__ppa_overlay__ .betssummary span{font-size:10px;color:#8993a6}
#__ppa_overlay__ .betslist{display:flex;flex-direction:column;gap:10px}
#__ppa_overlay__ .betcard{padding:11px;border:1px solid #2b313d;border-radius:11px;background:#151922}
#__ppa_overlay__ .bethead{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}
#__ppa_overlay__ .bethead>div b{display:block;color:#ffbd66;font-size:11px} #__ppa_overlay__ .bethead>div span{display:block;margin-top:3px;color:#8d96a8;font-size:9.5px}
#__ppa_overlay__ .bethead strong{color:#c9bfff;background:rgba(109,93,252,.13);border:1px solid rgba(129,112,255,.32);border-radius:999px;padding:4px 7px;font-size:9.5px;white-space:nowrap}
#__ppa_overlay__ .betfacts{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}
#__ppa_overlay__ .betfacts>div{padding:8px;border-radius:8px;background:#10141b;border:1px solid #252c37}
#__ppa_overlay__ .betfacts span{display:block;color:#7f899b;font-size:8.5px;margin-bottom:3px} #__ppa_overlay__ .betfacts b{font-size:12px;color:#e6e9ef}
#__ppa_overlay__ .betchat{margin-top:9px;padding:9px;border-radius:8px;background:#10141b;color:#bcc4d1;font-size:10px;line-height:1.45}
#__ppa_overlay__ .betcopy{width:100%;margin-top:8px;padding:8px;border-radius:8px;border:1px solid #343b49;background:#1a1f29;color:#d5dae4;font-size:10px;cursor:pointer}
#__ppa_overlay__ .emptybets{padding:16px;text-align:center;color:#818b9e;border:1px dashed #303744;border-radius:10px}
#__ppa_overlay__ .betcard.compact-series{padding:10px 11px}
#__ppa_overlay__ .compact-series .bethead{align-items:center}
#__ppa_overlay__ .compact-series .bethead>div b{color:#ffbd66;font-size:10.5px}
#__ppa_overlay__ .compact-series .bethead strong{font-size:10px;padding:5px 8px}
#__ppa_overlay__ .seriesfacts{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:9px}
#__ppa_overlay__ .seriesfacts>div{padding:7px 8px;border:1px solid #252c37;border-radius:8px;background:#10141b}
#__ppa_overlay__ .seriesfacts .balanceflow{grid-column:1/-1}
#__ppa_overlay__ .seriesfacts span{display:block;color:#7f899b;font-size:8.5px;margin-bottom:3px}
#__ppa_overlay__ .seriesfacts b{display:block;color:#e5e8ee;font-size:11px}
#__ppa_overlay__ .compact-series .betcopy{margin-top:7px;padding:7px}
#__ppa_overlay__ .betactions{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:7px}
#__ppa_overlay__ .compact-series .betactions .betcopy{margin-top:0;padding:7px}
#__ppa_overlay__ .betjump{padding:7px;border-radius:8px;border:1px solid #343b49;background:#1a1f29;color:#d5dae4;font-size:10px;cursor:pointer}
#__ppa_overlay__ .betjump:hover{background:#222833;color:#fff}



#__ppa_overlay__ .depositbetstats{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:9px}
#__ppa_overlay__ .depositbetstats>div{padding:8px;border:1px solid #252c37;border-radius:8px;background:#10141b}
#__ppa_overlay__ .depositbetstats span,#__ppa_overlay__ .betcycleflow span{display:block;color:#7f899b;font-size:8.5px;margin-bottom:3px}
#__ppa_overlay__ .depositbetstats b,#__ppa_overlay__ .betcycleflow b{display:block;color:#e5e8ee;font-size:11px;overflow-wrap:anywhere}
#__ppa_overlay__ .depositbetstats small{display:block;color:#8f99aa;font-size:8px;margin-top:2px}
#__ppa_overlay__ .betcycleflow{margin-top:6px;padding:8px;border:1px solid #252c37;border-radius:8px;background:#10141b}
#__ppa_overlay__ .bet-danger{color:#ff8d8d!important;border-color:rgba(255,100,100,.35)!important}
#__ppa_overlay__ .bet-high{color:#ffbd66!important;border-color:rgba(255,189,102,.35)!important}
#__ppa_overlay__ .bet-mid{color:#e8d47d!important}.bet-normal{color:#8fe7a4!important}

.wavesbtn{border:1px solid #303744;background:#191d25;color:#dce1e9;border-radius:7px;padding:6px 8px;font-size:10.5px;cursor:pointer}
.waves{display:none;margin-top:9px;padding-top:9px;border-top:1px solid #2d333e}
.waves.open{display:block}.wavestitle{font-size:10.5px;color:#9aa4b3;margin-bottom:6px;font-weight:800}
.wave{display:grid;grid-template-columns:30px 1fr auto;gap:7px;align-items:start;padding:9px 0;border-bottom:1px solid #222832;font-size:10.5px}
.wave:last-child{border-bottom:0}.waveidx{color:#778191;padding-top:1px}.waveinfo{color:#dce2ea;line-height:1.4}.wavetime{color:#aeb7c5}.wavegame{font-weight:750;color:#eef2f7;margin-top:2px}.wavedetails{color:#8f99aa;margin-top:3px}.wavedetails b{color:#dce2ea;font-weight:750}.waveratio{font-weight:900;color:#8fe7a4;white-space:nowrap}
.wavecopy{margin-top:5px;border:1px solid #303744;background:#191d25;color:#dce1e9;border-radius:6px;padding:4px 7px;font-size:9.5px;cursor:pointer}
.wavecopy:hover{background:#202530}.wavecopy.copied{color:#8fe7a4}
.wavesummary{font-size:10px;color:#8e98a7;margin-top:6px}.wave-tech{opacity:.7}#__ppa_overlay__ .smallbtn{border:1px solid #303744;background:#191d25;color:#dce1e9;border-radius:7px;padding:6px 8px;font-size:10.5px;cursor:pointer}#__ppa_overlay__ .copied{color:#8fe7a4}#__ppa_overlay__ .empty{text-align:center;color:#8f99aa;padding:30px 10px}#__ppa_overlay__ .settings label{display:grid;gap:7px;color:#b7c0cd;font-size:12px}#__ppa_overlay__ .settings select{padding:10px;background:#12161d;color:#fff;border:1px solid #303744;border-radius:9px}#__ppa_overlay__ .primary{width:100%;margin-top:12px;padding:10px;border:0;border-radius:9px;background:linear-gradient(135deg,#6757f7,#835cf7);color:#fff;font-weight:800;cursor:pointer}

/* v2.5.1 visual polish */
#__ppa_overlay__{border-color:rgba(139,120,255,.24)!important;background:linear-gradient(180deg,#0d1017,#0a0d13)!important;box-shadow:0 24px 70px rgba(0,0,0,.44),0 0 0 1px rgba(255,255,255,.018) inset!important}
#__ppa_overlay__ .head{background:linear-gradient(180deg,#181c27,#0f121a)!important;border-bottom-color:rgba(255,255,255,.06)!important}
#__ppa_overlay__ .subtitle{color:#7e889b!important}
#__ppa_overlay__ .tabbtn{transition:transform .16s ease,border-color .16s ease,background .16s ease,color .16s ease,box-shadow .16s ease}
#__ppa_overlay__ .tabbtn:hover{transform:translateY(-1px);border-color:#4b5364!important;color:#fff!important;background:#1b202b!important}
#__ppa_overlay__ .tabbtn.active{background:linear-gradient(135deg,#7657ff,#6548ee)!important;border-color:#8066ff!important;box-shadow:0 7px 20px rgba(101,72,238,.25),0 0 0 1px rgba(255,255,255,.08) inset}
#__ppa_overlay__ .body{padding:12px!important}
#__ppa_overlay__ .moment,#__ppa_overlay__ .gamecard,#__ppa_overlay__ .betcard{transition:transform .17s ease,border-color .17s ease,box-shadow .17s ease}
#__ppa_overlay__ .moment:hover,#__ppa_overlay__ .gamecard:hover,#__ppa_overlay__ .betcard:hover{transform:translateY(-1px);border-color:#3b4352!important;box-shadow:0 12px 28px rgba(0,0,0,.16)}
#__ppa_overlay__ .betsintro{background:linear-gradient(180deg,#11151d,#0f131a)!important;border-color:#292f3a!important;color:#929bad!important;padding:9px 11px!important;margin-bottom:8px!important}
#__ppa_overlay__ .betssummary{background:linear-gradient(135deg,rgba(117,86,255,.12),rgba(21,25,34,.9))!important;border-color:rgba(125,99,255,.25)!important;padding:9px 11px!important;margin-bottom:9px!important}
#__ppa_overlay__ .betcard.compact-series{position:relative;overflow:hidden;background:linear-gradient(180deg,#151a23,#121720)!important;border-color:#2d3441!important;padding:11px!important}
#__ppa_overlay__ .betcard.compact-series:before{content:"";position:absolute;left:0;top:0;bottom:0;width:2px;background:linear-gradient(180deg,#ffad42,#7558ff);opacity:.9}
#__ppa_overlay__ .compact-series .bethead strong{background:rgba(113,82,245,.13)!important;border-color:rgba(130,103,255,.38)!important;color:#d6ceff!important}
#__ppa_overlay__ .seriesfacts>div{background:rgba(13,17,24,.78)!important;border-color:#282f3a!important}
#__ppa_overlay__ .betactions button{transition:transform .15s ease,background .15s ease,border-color .15s ease,color .15s ease}
#__ppa_overlay__ .betactions button:hover{transform:translateY(-1px);background:#202632!important;border-color:#465064!important;color:#fff!important}
#__ppa_overlay__ ::-webkit-scrollbar{width:7px}
#__ppa_overlay__ ::-webkit-scrollbar-track{background:transparent}
#__ppa_overlay__ ::-webkit-scrollbar-thumb{background:#3b345c;border-radius:99px;border:2px solid #0c0f15}
#__ppa_overlay__ ::-webkit-scrollbar-thumb:hover{background:#5f4f9c}

#ppa-diag-page2{margin-left:6px;border:1px solid #574b8f;background:#171923;color:#d8dbea;border-radius:8px;padding:6px 9px;font-size:11px;font-weight:700;cursor:pointer}
#ppa-diag-page2:hover{border-color:#8068ff}
#ppa-diag-page2:disabled{opacity:.6;cursor:wait}
#ppa-diag-result{display:none;margin:8px 0;padding:9px 10px;border:1px solid #303748;border-radius:8px;background:#10131b;color:#cbd2df;font-size:11px;line-height:1.45;white-space:pre-wrap}
#ppa-diag-result.ok{display:block;border-color:#28513d;color:#9ee7bd}
#ppa-diag-result.err{display:block;border-color:#6b3434;color:#ffb0b0}

#__ppa_overlay__ .manager-wrap{display:grid;gap:10px}
#__ppa_overlay__ .manager-card{border:1px solid #2d3441;background:linear-gradient(180deg,#151a23,#11161e);border-radius:11px;padding:12px}
#__ppa_overlay__ .manager-label{font-size:9.5px;text-transform:uppercase;letter-spacing:.35px;color:#9c86ff;font-weight:900;margin-bottom:5px}
#__ppa_overlay__ .manager-name{font-size:16px;font-weight:900;color:#f1f3f8}
#__ppa_overlay__ .manager-phone{margin-top:4px;color:#aeb8c8;font-size:12px}
#__ppa_overlay__ .manager-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:9px}
#__ppa_overlay__ .manager-alert{border:1px solid #6c4c1e;background:#2a2110;color:#f1ce78;border-radius:10px;padding:11px;font-size:11px;line-height:1.45}
#__ppa_overlay__ .manager-alert.good{border-color:#28513d;background:#10291d;color:#9ee7bd}

#__ppa_overlay__ .manager-alert-neutral{border-color:#394353!important;background:#171c25!important;color:#c8d0dc!important}
#__ppa_overlay__ .manager-service-status{margin-top:5px;font-size:11px;color:#f1ce78;font-weight:800}

#__ppa_overlay__ .manager-net-card{border:1px solid #3b4250;background:linear-gradient(180deg,#151b24,#111720);border-radius:12px;padding:12px;margin-bottom:10px}
#__ppa_overlay__ .manager-net-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.manager-net-head>div{min-width:0}
#__ppa_overlay__ .manager-net-head b{display:block;color:#a98cff;font-size:11px;text-transform:uppercase}#__ppa_overlay__ .manager-net-head span{display:block;color:#8f99aa;font-size:9.5px;margin-top:3px}
#__ppa_overlay__ .manager-net-head em{font-style:normal;color:#7f8998;font-size:8.5px;white-space:nowrap;border:1px solid #313947;border-radius:999px;padding:3px 6px}
#__ppa_overlay__ .manager-net-basis{margin-top:8px;color:#aeb7c5;font-size:9.5px;line-height:1.4}
#__ppa_overlay__ .manager-net-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}#__ppa_overlay__ .manager-net-grid>div{border:1px solid #2b3340;background:#0f141b;border-radius:9px;padding:8px}
#__ppa_overlay__ .manager-net-grid .wide{grid-column:1/-1;display:grid;grid-template-columns:1fr auto;align-items:end;column-gap:8px}#__ppa_overlay__ .manager-net-grid span{display:block;color:#818c9d;font-size:8.5px;margin-bottom:3px}#__ppa_overlay__ .manager-net-grid b{font-size:12px;color:#eef1f6}#__ppa_overlay__ .manager-net-grid b.loss{color:#ff9b9b}#__ppa_overlay__ .manager-net-grid b.plus{color:#8ce7aa}#__ppa_overlay__ .manager-net-grid small{grid-column:1/-1;color:#7f8998;font-size:8.5px;margin-top:4px}
#__ppa_overlay__ .manager-net-verdict{margin-top:9px;border-radius:9px;padding:9px 10px;font-size:9.5px;line-height:1.45;font-weight:750}#__ppa_overlay__ .manager-net-verdict.ok{border:1px solid #285b3b;background:#10291b;color:#9ee7bd}#__ppa_overlay__ .manager-net-verdict.wait{border:1px solid #66552e;background:#2a2414;color:#f2ce7e}#__ppa_overlay__ .manager-net-verdict.no{border:1px solid #663838;background:#2b1719;color:#ffaaaa}
#__ppa_overlay__ .bonus-loading{border:1px solid #303744;background:#141922;border-radius:11px;padding:16px;color:#e7ebf2;font-size:12px}
#__ppa_overlay__ .bonus-loading span{display:inline-block;margin-top:5px;color:#929cac;font-size:10.5px}
#__ppa_overlay__ .manager-bonus-intro{border:1px solid #343b48;background:#141922;border-radius:11px;padding:12px;margin-bottom:10px}
#__ppa_overlay__ .manager-bonus-intro>div:first-child{display:flex;align-items:center;justify-content:space-between;gap:10px;color:#a98cff;font-size:11px;text-transform:uppercase;font-weight:900}
#__ppa_overlay__ .manager-bonus-intro>div:first-child span{color:#9aa4b4;font-size:10px;text-transform:none}
#__ppa_overlay__ .manager-bonus-note{margin-top:6px;color:#929cac;font-size:10px;line-height:1.4}
#__ppa_overlay__ .manager-bonus-list{display:flex;flex-direction:column;gap:8px}
#__ppa_overlay__ .manager-bonus-card{border:1px solid #303744;background:#141922;border-radius:11px;padding:11px}
#__ppa_overlay__ .manager-bonus-top{display:flex;justify-content:space-between;align-items:flex-start;gap:9px}
#__ppa_overlay__ .manager-bonus-date{font-size:9.5px;color:#8f99aa;margin-bottom:3px}
#__ppa_overlay__ .manager-bonus-name{font-size:11.5px;color:#f1f3f7;font-weight:850;line-height:1.3}
#__ppa_overlay__ .bonus-status{flex:0 0 auto;border:1px solid #3a4351;border-radius:999px;padding:3px 7px;font-size:9px;font-weight:850}
#__ppa_overlay__ .bonus-status.done{color:#8ce7aa;border-color:#285b3b;background:#10291b}
#__ppa_overlay__ .bonus-status.rejected{color:#ffaaaa;border-color:#663838;background:#2b1719}
#__ppa_overlay__ .bonus-status.expired{color:#f2ce7e;border-color:#66552e;background:#2a2414}
#__ppa_overlay__ .bonus-status.canceled{color:#c2c8d2;background:#20252d}
#__ppa_overlay__ .bonus-status.other{color:#c8d0dc}
#__ppa_overlay__ .manager-bonus-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}
#__ppa_overlay__ .manager-bonus-grid>div{border:1px solid #29313d;background:#10151c;border-radius:8px;padding:7px 8px;min-width:0}
#__ppa_overlay__ .manager-bonus-grid span{display:block;color:#818c9d;font-size:8.5px;margin-bottom:2px}
#__ppa_overlay__ .manager-bonus-grid b{display:block;color:#e9edf3;font-size:10.5px;overflow-wrap:anywhere}
#__ppa_overlay__ .manager-bonus-id{margin-top:7px;color:#737e8e;font-size:8.5px}
#__ppa_overlay__ .manager-alert-critical{border-color:#8a3f35!important;background:#301716!important;color:#ffd0c8!important}
#__ppa_overlay__ .manager-next{margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,.12);line-height:1.55}
#__ppa_overlay__ .manager-status.detach{border-color:#8a3f35;background:#301716;color:#ffad9f}
#__ppa_overlay__ .manager-status.action{border-color:#6c4c1e;background:#2a2110;color:#f1ce78}
#__ppa_overlay__ .manager-comments{display:grid;gap:8px}
#__ppa_overlay__ .manager-comment{border:1px solid #2b323d;background:#121720;border-radius:10px;padding:10px}
#__ppa_overlay__ .manager-comment-head{display:flex;justify-content:space-between;gap:10px;margin-bottom:6px;font-size:10px;color:#8994a5}
#__ppa_overlay__ .manager-comment-author{color:#c9d0dc;font-weight:800}
#__ppa_overlay__ .manager-comment-text{white-space:pre-wrap;color:#d9dee7;font-size:11px;line-height:1.45}
#__ppa_overlay__ .manager-status{display:inline-flex;align-items:center;border:1px solid #3b4350;border-radius:999px;padding:2px 7px;font-size:9px;font-weight:900;white-space:nowrap}
#__ppa_overlay__ .manager-status.fail{border-color:#6b3434;background:#2c1719;color:#ff9b9b}
#__ppa_overlay__ .manager-status.ok{border-color:#28513d;background:#10291d;color:#9ee7bd}
#__ppa_overlay__ .manager-status.neutral{color:#9aa4b3}
#__ppa_overlay__ .manager-empty{padding:25px 12px;text-align:center;color:#8f99aa}

#__ppa_overlay__[data-ppa-context="manager"] .head{padding:14px 16px!important}
#__ppa_overlay__[data-ppa-context="manager"] .brand{flex:1;min-width:0}
#__ppa_overlay__[data-ppa-context="manager"] .brand>div:last-child{min-width:0}
#__ppa_overlay__[data-ppa-context="manager"] .title{font-size:16px;white-space:nowrap}
#__ppa_overlay__[data-ppa-context="manager"] .sub{font-size:10px;white-space:nowrap}
#__ppa_overlay__[data-ppa-context="manager"] .actions{flex:0 0 auto}
#__ppa_overlay__[data-ppa-context="manager"] .tabs{display:flex!important;flex:0 0 auto;margin-left:auto;gap:6px}
#__ppa_overlay__[data-ppa-context="manager"] .tabbtn{padding:7px 9px;font-size:9.5px;white-space:nowrap}
#__ppa_overlay__[data-ppa-context="manager"] .logo{flex:0 0 auto}



/* v2.9.3: only Games-specific styling; header and launcher use original visuals */
#__ppa_overlay__ .club-millionaires-card{
  order:-1!important;
  border:1px solid #51478a!important;
  box-shadow:inset 3px 0 0 #6d5dfc!important;
}
#__ppa_overlay__ .clubtag{
  display:inline-flex;align-items:center;margin-bottom:8px;padding:4px 7px;
  border-radius:6px;background:rgba(109,93,252,.14);color:#a99cff;
  font-size:9px;font-weight:800;letter-spacing:.35px;
}
#__ppa_overlay__ .clubgrid{grid-template-columns:1fr 1fr!important}

/* v3.0.7 — final header polish: preserve logo proportions and give tabs breathing room */
#__ppa_overlay__ .head{
  position:relative!important;display:flex!important;flex-wrap:wrap!important;align-items:center!important;
  gap:11px 0!important;padding:13px 14px 12px!important;overflow:visible!important;
}
#__ppa_overlay__ .brand{
  flex:0 0 auto!important;min-width:0!important;padding-right:72px!important;gap:10px!important;
}
#__ppa_overlay__ .logo{
  width:36px!important;height:36px!important;min-width:36px!important;min-height:36px!important;
  flex:0 0 36px!important;aspect-ratio:1 / 1!important;border-radius:11px!important;
}
#__ppa_overlay__ .logo img{
  width:100%!important;height:100%!important;min-width:100%!important;object-fit:contain!important;
  object-position:center!important;transform:none!important;
}
#__ppa_overlay__ .title{font-size:15px!important;line-height:1.1!important;white-space:nowrap!important}
#__ppa_overlay__ .sub{font-size:9.5px!important;line-height:1.25!important;white-space:nowrap!important}
#__ppa_overlay__ .actions{
  width:100%!important;display:flex!important;align-items:center!important;gap:0!important;overflow:visible!important;
}
#__ppa_overlay__ .tabs{
  position:static!important;display:flex!important;flex:1 1 auto!important;gap:7px!important;
  padding:0!important;background:transparent!important;overflow:visible!important;
}
#__ppa_overlay__ .tabbtn{
  position:relative!important;min-height:36px!important;padding:0 12px!important;border-radius:10px!important;
  display:inline-flex!important;align-items:center!important;justify-content:center!important;text-align:center!important;line-height:1.15!important;
  border:1px solid #30384a!important;background:linear-gradient(180deg,#171c27,#131821)!important;
  color:#b8c1d0!important;font-size:10px!important;font-weight:700!important;white-space:nowrap!important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.025)!important;
  transition:transform .16s ease,border-color .16s ease,background .16s ease,color .16s ease,box-shadow .16s ease!important;
}
#__ppa_overlay__ .tabbtn:hover{
  transform:translateY(-1px)!important;border-color:#665b91!important;color:#fff!important;
  background:linear-gradient(180deg,#202637,#171c28)!important;box-shadow:0 5px 15px rgba(0,0,0,.18)!important;
}
#__ppa_overlay__ .tabbtn.active{
  border-color:#8068ff!important;color:#fff!important;background:linear-gradient(135deg,#755cff,#6849ee)!important;
  box-shadow:0 7px 18px rgba(109,79,244,.30),inset 0 1px 0 rgba(255,255,255,.18)!important;
  transform:none!important;
}
#__ppa_overlay__ .iconbtn{position:absolute!important;top:14px!important;width:30px!important;height:30px!important;padding:0!important;display:grid!important;place-items:center!important}
#__ppa_overlay__ .minbtn{right:48px!important}
#__ppa_overlay__ .close{right:13px!important;font-size:17px!important}
#__ppa_overlay__[data-ppa-context="manager"] .head{padding:13px 14px 12px!important}
#__ppa_overlay__[data-ppa-context="manager"] .brand{flex:0 0 auto!important;padding-right:72px!important}
#__ppa_overlay__[data-ppa-context="manager"] .actions{width:100%!important}
#__ppa_overlay__[data-ppa-context="manager"] .tabs{margin-left:0!important;gap:7px!important}
#__ppa_overlay__[data-ppa-context="manager"] .tabbtn{padding:0 13px!important;font-size:10px!important}
#__ppa_overlay__.ppa-minimized .head{display:flex!important;flex-wrap:nowrap!important;padding:10px!important}
#__ppa_overlay__.ppa-minimized .brand{padding-right:0!important}
#__ppa_overlay__.ppa-minimized .logo{width:38px!important;height:38px!important;min-width:38px!important;min-height:38px!important;flex-basis:38px!important}
</style>
<div class="head"><div class="brand"><div class="logo"><img src="${chrome.runtime.getURL('icon32.png')}" alt="P" onerror="this.style.display='none';this.parentElement.textContent='P'"></div><div><div class="title">Player <span class="insight">Insight</span></div><div class="sub">Аналіз за останні 14 днів</div></div></div><div class="actions"><div class="tabs"><button class="tabbtn active" data-tab="balance">Аналіз ЖБ</button><button class="tabbtn" data-tab="negative">Негатив</button><button class="tabbtn" data-tab="games">Ігри</button><button class="tabbtn" data-tab="bets">Ставки</button><button class="tabbtn" data-tab="manager">Менеджер</button><button class="tabbtn" data-tab="bonuses">🎁 Бонуси</button></div><button class="iconbtn minbtn" title="Згорнути">−</button><button class="iconbtn close" title="Закрити">×</button></div></div><div class="body"></div>`;
  document.body.appendChild(root);
  ppaApplyContextUI(root);
  root.querySelector('.close').onclick=()=>{
    try{
      localStorage.setItem('__ppa_minimized__','0');
      window.__ppa_closed_this_page__=true;
    }catch{}
    root.remove();
  };
  // v2.8.2: manager page can open without running ЖБ analysis, so setupTabs()
  // may never be called. Delegate tab clicks at shell level.
  root.addEventListener('click',ev=>{
    const btn=ev.target.closest?.('.tabbtn');
    if(!btn || !root.contains(btn))return;
    ev.preventDefault();
    ev.stopPropagation();
    activateTab(root,btn.dataset.tab,root.__ppaTabResult||window.__ppa_last_result__||{ok:false},root.__ppaTabMult||2);
  });

  const refreshBtn=root.querySelector('.refresh');
  if(refreshBtn) refreshBtn.onclick=()=>{
    if(__ppaAnalyzing)return;
    __ppaAnalyzing=true;refreshBtn.classList.add('loading');
    requestAnimationFrame(()=>{
      try{
        const fresh=analyze(2);window.__ppa_last_result__=fresh;
        setupTabs(root,fresh,2);activateTab(root,'balance',fresh,2);
        const u=root.querySelector('.updated');if(u)u.textContent='Оновлено '+ppaTimeNow();
      }finally{__ppaAnalyzing=false;refreshBtn.classList.remove('loading');}
    });
  };
  const u=root.querySelector('.updated');if(u)u.textContent='Оновлено '+ppaTimeNow();


  const dockGap=14;
  let dragState=null;
  let suppressOpen=false;

  function clampDockTop(y){
    return Math.max(dockGap,Math.min(window.innerHeight-root.offsetHeight-dockGap,y));
  }

  function setPos(prop,value){
    root.style.setProperty(prop,value,'important');
  }

  function applyDock(side,top,animate=true){
    root.classList.toggle('ppa-dock-left',side==='left');
    root.classList.toggle('ppa-dock-right',side!=='left');
    if(!animate)root.classList.add('ppa-dragging');

    setPos('top',`${clampDockTop(top)}px`);
    setPos('bottom','auto');
    if(side==='left'){
      setPos('left',`${dockGap}px`);
      setPos('right','auto');
    }else{
      // У згорнутому режимі завжди анімуємо через left.
      // Якщо перемикати left -> auto і right -> 10px, браузер не може
      // плавно інтерполювати позицію, тому правий snap виглядав миттєвим.
      const rightLeft=Math.max(dockGap,window.innerWidth-root.offsetWidth-dockGap);
      setPos('left',`${rightLeft}px`);
      setPos('right','auto');
    }

    try{
      localStorage.setItem('__ppa_dock_side__',side);
      localStorage.setItem('__ppa_dock_top__',String(clampDockTop(top)));
    }catch{}

    if(!animate)requestAnimationFrame(()=>root.classList.remove('ppa-dragging'));
  }

  function minimizePanel(persist=true){
    const rect=root.getBoundingClientRect();
    if(persist){try{localStorage.setItem('__ppa_minimized__','1')}catch{}}
    root.classList.add('ppa-minimized');
    root.title='Player Insight — перетягніть або натисніть, щоб розгорнути';

    let side='right';
    let top=rect.top;
    try{
      side=localStorage.getItem('__ppa_dock_side__')||'right';
      const savedTop=Number(localStorage.getItem('__ppa_dock_top__'));
      if(Number.isFinite(savedTop))top=savedTop;
    }catch{}
    applyDock(side,top,true);
  }

  function expandPanel(){
    try{localStorage.setItem('__ppa_minimized__','0')}catch{}
    root.classList.remove('ppa-minimized','ppa-dock-left','ppa-dock-right','ppa-dragging');
    root.title='';
    // Незалежно від місця згорнутої іконки повна панель завжди відкривається справа.
    setPos('left','auto');
    setPos('right','10px');
    setPos('top','10px');
    setPos('bottom','auto');
    setPos('transform','none');
    animateSection(root);
  }

  const min=root.querySelector('.minbtn');
  if(min)min.onclick=(ev)=>{
    ev.preventDefault();
    ev.stopPropagation();
    minimizePanel();
  };

  root.addEventListener('pointerdown',ev=>{
    if(!root.classList.contains('ppa-minimized'))return;
    if(ev.button!==0 && ev.pointerType!=='touch')return;

    const rect=root.getBoundingClientRect();
    dragState={
      id:ev.pointerId,
      startX:ev.clientX,
      startY:ev.clientY,
      offsetX:ev.clientX-rect.left,
      offsetY:ev.clientY-rect.top,
      moved:false
    };
    suppressOpen=false;
    root.setPointerCapture?.(ev.pointerId);
    root.classList.add('ppa-dragging');
    ev.preventDefault();
  });

  root.addEventListener('pointermove',ev=>{
    if(!dragState || dragState.id!==ev.pointerId || !root.classList.contains('ppa-minimized'))return;

    const dx=ev.clientX-dragState.startX;
    const dy=ev.clientY-dragState.startY;
    if(Math.hypot(dx,dy)>4)dragState.moved=true;
    if(!dragState.moved)return;

    const x=Math.max(0,Math.min(window.innerWidth-root.offsetWidth,ev.clientX-dragState.offsetX));
    const y=clampDockTop(ev.clientY-dragState.offsetY);

    setPos('left',`${x}px`);
    setPos('right','auto');
    setPos('top',`${y}px`);
    setPos('bottom','auto');
    ev.preventDefault();
  });

  function finishDockDrag(ev){
    if(!dragState || dragState.id!==ev.pointerId)return;
    const moved=dragState.moved;
    const rect=root.getBoundingClientRect();
    dragState=null;
    root.releasePointerCapture?.(ev.pointerId);
    root.classList.remove('ppa-dragging');

    if(moved){
      const side=(rect.left+rect.width/2)<window.innerWidth/2?'left':'right';
      suppressOpen=true;
      applyDock(side,rect.top,true);
      setTimeout(()=>{suppressOpen=false},180);
    }
  }

  root.addEventListener('pointerup',finishDockDrag);
  root.addEventListener('pointercancel',finishDockDrag);

  window.addEventListener('pointermove',ev=>{
    if(!dragState || dragState.id!==ev.pointerId || !root.classList.contains('ppa-minimized'))return;
    const dx=ev.clientX-dragState.startX;
    const dy=ev.clientY-dragState.startY;
    if(Math.hypot(dx,dy)>4)dragState.moved=true;
    if(!dragState.moved)return;

    const x=Math.max(0,Math.min(window.innerWidth-root.offsetWidth,ev.clientX-dragState.offsetX));
    const y=clampDockTop(ev.clientY-dragState.offsetY);
    setPos('left',`${x}px`);
    setPos('right','auto');
    setPos('top',`${y}px`);
    setPos('bottom','auto');
    ev.preventDefault();
  },{passive:false});

  window.addEventListener('pointerup',finishDockDrag);
  window.addEventListener('pointercancel',finishDockDrag);

  root.addEventListener('click',ev=>{
    if(!root.classList.contains('ppa-minimized'))return;
    if(suppressOpen)return;
    ppaApplyContextUI(root);
    if(!ppaIsBalanceJournal()){
      if(ppaHasManagerCardData()){
        expandPanel();
        activateTab(root,'manager',window.__ppa_last_result__||{ok:false},2,{skipRestore:true});
      }else{
        ppaShowBalanceNotice(root,'На цій сторінці Player Insight поки не знайшов дані для аналізу.');
      }
      return;
    }

    // Open immediately. Never block the click with a synchronous one-page analyze.
    expandPanel();
    root.dataset.period=root.dataset.period||'14';

    const body=root.querySelector('.body');
    if(body && !window.__ppa_last_result__){
      body.innerHTML='<div style="padding:18px 14px;color:#aeb6c7;font-size:12px;line-height:1.5"><b style="color:#ddd">Готую аналіз за 14 днів…</b><br><span style="color:#747f91">Player Insight читає ЖБ у фоні. Панель і браузер залишаються доступними.</span></div>';
    }

    // If background warm-up already finished this is instant.
    // If it is still running, __PPA_ANALYZE__ joins the same promise instead of starting a second scan.
    Promise.resolve().then(()=>window.__PPA_ANALYZE__?.(2,{preferCache:true}));
  });

  window.addEventListener('resize',()=>{
    if(!root.isConnected || !root.classList.contains('ppa-minimized'))return;
    const rect=root.getBoundingClientRect();
    const side=root.classList.contains('ppa-dock-left')?'left':'right';
    applyDock(side,rect.top,true);
  });

  try{
    if(localStorage.getItem('__ppa_minimized__')==='1'){
      requestAnimationFrame(()=>minimizePanel(false));
    }
  }catch{}

  return root;
}


function timelineEvents(e){
  const rows=[];
  rows.push({type:'deposit',time:e.depTime||e.startTime,label:'Депозит',balance:e.deposit||e.amt,sub:e.id?`ID ${e.id}`:''});

  const waves=[...(e.waves||[])].sort((a,b)=>new Date(a.time||a.peakTime||0)-new Date(b.time||b.peakTime||0));
  waves.forEach((w,i)=>{
    const bal=Number(w.balance ?? w.peak ?? w.peakBalance ?? 0);
    const ratio=Number(w.ratio || (bal && (e.deposit||e.amt) ? bal/(e.deposit||e.amt) : 0));
    rows.push({
      type:'peak',
      time:w.time||w.peakTime,
      label:`Підйом #${i+1}${ratio?` · x${compactX(ratio)}`:''}`,
      balance:bal,
      sub:w.game?gameName(w.game):''
    });
  });

  // Always include the strongest peak if waves don't already contain it.
  const peak=Number(e.peak||0);
  if(peak && !rows.some(x=>x.type==='peak' && Math.abs(Number(x.balance)-peak)<0.01)){
    rows.push({type:'peak',time:e.peakTime,label:`Максимальний баланс · x${compactX(e.ratio||0)}`,balance:peak,sub:e.game?gameName(e.game):''});
  }

  if(Number(e.withdrawn||0)>0){
    rows.push({type:'withdraw',time:e.withdrawTime||e.lastWithdrawTime,label:'Виведення коштів',balance:Number(e.withdrawn||0),sub:'Сума підтвердженого виводу'});
  }

  rows.push({
    type:'end',
    time:e.endTime||e.nextDepositTime,
    label:e.lost?'Баланс перед новим депозитом':'Баланс наприкінці циклу',
    balance:Number(e.endBal||0),
    sub:e.lost?'Після цього почався новий депозитний цикл':''
  });

  return rows.filter(x=>x.balance!==undefined && x.balance!==null);
}

function renderTimeline(card,e){
  const old=card.querySelector('.timeline-wrap');
  if(old){old.remove();return}
  const wrap=document.createElement('div');
  wrap.className='timeline-wrap';
  const rows=timelineEvents(e);
  wrap.innerHTML=`<div class="timeline-title"><b>Шлях депозиту</b><button class="timeline-close" title="Закрити">×</button></div>
    <div class="tl">${rows.map(x=>`
      <div class="tl-row ${x.type}">
        <span class="tl-dot"></span>
        <div class="tl-main">
          <span class="tl-label">${x.label}</span>
          <span class="tl-bal ${x.type==='peak'?'tl-peak':''}">${MONEY.format(Number(x.balance||0))} грн</span>
        </div>
        <div class="tl-sub">${x.time?fmtDate(x.time):''}${x.sub?` · ${x.sub}`:''}</div>
      </div>`).join('')}
    </div>`;
  wrap.querySelector('.timeline-close').onclick=()=>{
    wrap.remove();
    const btn=card.querySelector('.timeline-btn');
    if(btn)btn.textContent='◉ Шлях депозиту';
  };
  card.appendChild(wrap);
  wrap.scrollIntoView({block:'nearest',behavior:'smooth'});
}


function jumpToJournalRow(time, type, game='', amount=null){
  if(!time)return;
  const target=fmtDate(time);
  const trs=[...document.querySelectorAll('tr')];
  const wantGame=String(game||'').trim().toLowerCase();
  const wantAmount=Number(amount);

  const matches=(tr, strict=true)=>{
    const cells=tr.cells||[];
    if((cells[0]?.textContent||'').trim()!==target)return false;

    const cls=String(tr.className||'').toLowerCase();
    const action=(cells[4]?.textContent||'').trim().toLowerCase();

    if(type==='deposit' && !(cls.includes('input')||action.includes('ввод')))return false;
    if(type==='win' && !(cls.includes('win')||action==='win'))return false;
    if(type==='withdraw' && !(cls.includes('withdraw')||action.includes('вывод')))return false;
    if(type==='bet' && !(cls.includes('bet')||action==='bet'))return false;

    if(strict && wantGame){
      const rowGame=(cells[3]?.textContent||'').trim().toLowerCase();
      if(rowGame!==wantGame)return false;
    }
    if(strict && Number.isFinite(wantAmount)){
      const rowAmount=Math.abs(parseMoney(cells[5]?.textContent));
      if(!Number.isFinite(rowAmount)||Math.abs(rowAmount-Math.abs(wantAmount))>0.0001)return false;
    }
    return true;
  };

  let row=trs.find(tr=>matches(tr,true));
  if(!row)row=trs.find(tr=>matches(tr,false));
  if(!row)return;

  row.scrollIntoView({behavior:'smooth',block:'center'});
  row.classList.remove('__ppa_row_flash__');
  void row.offsetWidth;
  row.classList.add('__ppa_row_flash__');
  setTimeout(()=>row.classList.remove('__ppa_row_flash__'),2400);
}
function periodCutoff(days){
  if(days>=14)return null;
  const d=new Date();
  if(days===0){d.setHours(0,0,0,0);return d}
  d.setDate(d.getDate()-days); return d;
}
function filterResultPeriod(r,days){
  const cutoff=periodCutoff(days);
  if(!cutoff)return r;
  const episodes=(r.episodes||[]).filter(e=>new Date(e.depTime||e.time||e.startTime||e.peakTime||0)>=cutoff);
  const depositList=(r.depositList||[]).filter(d=>new Date(d.date)>=cutoff);
  return {...r,episodes,count:episodes.length,deposits:depositList.length,depositList,depositSum:depositList.reduce((s,d)=>s+Number(d.amount||0),0)};
}
function totalWithdrawalOps(r){
  return (r.episodes||[]).reduce((s,e)=>s+(Number.isFinite(Number(e.withdrawCount))?Number(e.withdrawCount):(Number(e.withdrawn||0)>0?1:0)),0);
}
function withdrawalWord(n){
  const x=Math.abs(Number(n)||0)%100, y=x%10;
  if(x>=11&&x<=14)return 'виводів';
  if(y===1)return 'вивід';
  if(y>=2&&y<=4)return 'виводи';
  return 'виводів';
}
function periodRangeLabel(days,r){
  const end=new Date();
  let start=new Date(end);
  const n=Number(days||0);
  if(n===0){
    start.setHours(0,0,0,0);
  }else{
    start.setDate(end.getDate()-(n-1));
    start.setHours(0,0,0,0);
  }
  const f=d=>`${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}`;
  return `${f(start)} — ${f(end)}`;
}
function latestDepositBlock(r){
  const e=[...(r.episodes||[])].sort((a,b)=>new Date(b.depTime||b.time||b.startTime||0)-new Date(a.depTime||a.time||a.startTime||0))[0];
  if(!e)return '';
  return `<div class="lastdep"><div class="lastdep-title">Останній позитивний результат після депозиту</div>
    <div class="lastdep-main">${MONEY.format(e.amt||0)} → ${MONEY.format(e.peak||e.endBal||0)} грн ${e.ratio?`· x${compactX(e.ratio)}`:''}</div>
    <div class="lastdep-sub">${fmtDate(e.depTime||e.time||e.startTime)} · Виведено: ${MONEY.format(e.withdrawn||0)} грн · Баланс наприкінці: ${MONEY.format(e.endBal||0)} грн</div>
  </div>`;
}
function durationShort(a,b){
  if(!a||!b)return '';
  const ms=Math.max(0,new Date(b)-new Date(a));
  const mins=Math.round(ms/60000);
  if(mins<60)return `${Math.max(1,mins)} хв`;
  const h=Math.floor(mins/60), mm=mins%60;
  return mm?`${h} год ${mm} хв`:`${h} год`;
}
function afterPeakText(e){
  const end=e.endTime||e.nextDepositTime||e.lastWithdrawTime||e.withdrawTime||e.peakTime;
  const span=durationShort(e.depTime||e.time,end);
  const dayNote=e.crossedDay?' · гра перейшла на наступний день':'';
  if(Number(e.withdrawn||0)>0){
    const d=durationShort(e.peakTime,e.withdrawTime||e.lastWithdrawTime);
    return `Депозит відстежено${span?` ${span}`:''}${dayNote}. Після піку${d?` через ${d}`:''} виведено ${MONEY.format(e.withdrawn)} грн · фінальний баланс ${MONEY.format(e.endBal||0)} грн`;
  }
  if(e.lost)return `Депозит відстежено${span?` ${span}`:''}${dayNote} · гру продовжено, кошти витрачено${e.nextDepositTime?' до наступного депозиту':''}`;
  if(e.lifecycleStatus==='closed')return `Депозит відстежено${span?` ${span}`:''}${dayNote} · цикл завершився перед наступним депозитом · залишок ${MONEY.format(e.endBal||0)} грн`;
  return `Депозит відстежується${span?` ${span}`:''}${dayNote} · підтверджений вивід не знайдено · останній доступний баланс ${MONEY.format(e.endBal||0)} грн`;
}

function renderBalance(root,r,m){
  const body=root.querySelector('.body');
  const selected=Number(root.dataset.period ?? 14);
  const rr=filterResultPeriod(r,selected);
  r=rr;
  const best=r.episodes.length?Math.max(...r.episodes.map(e=>e.ratio)):0;

  body.innerHTML=`<div class="periods"><button class="periodbtn ${selected===0?'active':''}" data-days="0">Сьогодні</button><button class="periodbtn ${selected===3?'active':''}" data-days="3">3 дні</button><button class="periodbtn ${selected===7?'active':''}" data-days="7">7 днів</button><button class="periodbtn ${selected===14?'active':''}" data-days="14">14 днів</button><span class="rangehint">${periodRangeLabel(selected,r)}</span></div>${latestDepositBlock(r)}<div class="stats stats-wide">
    <div class="stat"><b>${r.deposits}</b><span>депозити за період</span></div>
    <div class="stat"><b>${best?`x${best.toFixed(1)}`:'—'}</b><span>максимальне зростання</span></div>
    <div class="stat"><b>${MONEY.format(r.depositSum||0)} грн</b><span>сума депозитів</span></div>
    <div class="stat"><b>${r.deposits?`${r.count} із ${r.deposits} · ${Math.round(r.count/r.deposits*100)}%`:'—'}</b><span>депозити з x2+${r.incomplete?'<small class="data-note">за доступними даними</small>':''}</span></div>
    <div class="stat withdrawal-stat"><div class="withdraw-main"><b>${MONEY.format((r.episodes||[]).reduce((s,e)=>s+Number(e.withdrawn||0),0))} грн</b><strong>${totalWithdrawalOps(r)} ${withdrawalWord(totalWithdrawalOps(r))}</strong></div><span>виведено після x2+</span></div>
  </div>
  ${r.journalFetchError
 ? `<div class="warn">⚠ <b>Збір сторінок ЖБ зупинено:</b> ${esc(r.journalFetchError)}<br>Проаналізовано доступні дані вибраного періоду · ${r.journalPages||1} стор.</div>`
 : r.incomplete
 ? `<div class="warn">⚠ Проаналізовано доступні дані вибраного періоду · прочитано ${r.journalPages||1} стор. До початку періоду ЖБ ще не дійшов.</div>`
 : `<div class="warn" style="border-color:#284a3a;background:#10231b;color:#9ee7bd">✓ Проаналізовано <b>${fmtDate(r.periodStart)} — ${fmtDate(r.periodEnd)}</b> · прочитано ${r.journalPages||1} стор.</div>`}
  <div class="filters">
    <button class="filterbtn active" data-range="all">Усі x2+</button>
    <button class="filterbtn" data-range="2-3">x2–3</button>
    <button class="filterbtn" data-range="3-5">x3–5</button>
    <button class="filterbtn" data-range="5-10">x5–10</button>
    <button class="filterbtn" data-range="10+">x10+</button>
  </div>
  <div class="tools"><span>${r.total} операцій · ${r.journalPages||1} стор. ЖБ проаналізовано</span><div class="toolright"><button class="compactbtn" title="Компактний вигляд">▤ Компактно</button><select class="sort"><option value="newPeak">Спочатку нові</option><option value="ratio">Найбільший X</option></select></div></div>
    <div id="ppa-diag-result"></div>
  <div class="cards"></div>`;

  const cards=body.querySelector('.cards');

  let activeRange='all';
  function inRange(e,range){
    if(range==='2-3')return e.ratio>=2&&e.ratio<3;
    if(range==='3-5')return e.ratio>=3&&e.ratio<5;
    if(range==='5-10')return e.ratio>=5&&e.ratio<10;
    if(range==='10+')return e.ratio>=10;
    return e.ratio>=2;
  }
  function draw(mode='ratio',range=activeRange){
    cards.innerHTML='';
    let list=[...r.episodes].filter(e=>inRange(e,range));
    if(mode==='newPeak')list.sort((a,b)=>b.peakTime-a.peakTime);
    else list.sort((a,b)=>b.ratio-a.ratio);

    if(!list.length){
      cards.innerHTML='<div class="empty">У цьому діапазоні підйомів не знайдено.</div>';
      return;
    }

    list.forEach(e=>{
      const [ico,label,cls]=tier(e.ratio),c=document.createElement('div');
      c.className=`card ${cls}`;

      let st,sc;
      if(e.withdrawn>0){
        st=`✓ Виведено після піку: ${MONEY.format(e.withdrawn)} грн`;sc='st-ok';
      }else if(e.lost){
        st='✕ Не вивів · баланс витрачено до наступного депозиту';sc='st-bad';
      }else{
        st='! Підтверджений вивід після піку не знайдено';sc='st-mid';
      }

      c.innerHTML=`<div class="accent"></div><div class="cardin">
        <div class="tag">${ico} ${label}</div>
        <div class="hero"><div class="money">${MONEY.format(e.amt)} → ${MONEY.format(e.peak)} грн</div><div class="ratio">x${e.ratio.toFixed(2)}</div></div>
        <div class="grid">
          <div class="k">ID депозиту</div><div class="v">${e.id}</div>
          <div class="k">Дата депозиту</div><div class="v">${fmtDate(e.time)}</div>
          <div class="k">Гра на піку</div><div class="v">${gameName(e.game)}</div>
          <div class="k">Ставка</div><div class="v">${e.betAmount?`${MONEY.format(e.betAmount)} грн`:'—'}</div>
          <div class="k">Час піку</div><div class="v">${fmtDate(e.peakTime)}</div>
          <div class="k">Баланс наприкінці</div><div class="v">${MONEY.format(e.endBal)} грн</div>
        </div>
        <div class="afterpeak"><span>Що було далі з депозитом</span><b>${afterPeakText(e)}</b></div>
        <div class="status ${sc}">${st}</div>
        <div class="cardfoot">
          <button class="smallbtn copy">📋 Скопіювати</button>
          ${e.waves&&e.waves.length>1?`<button class="wavesbtn">↕ Підйоми x2+ (${e.waves.length})</button>`:''}
          <span class="jumpgroup"><button class="jumpbtn" data-jump="deposit">↗ Депозит</button>
          <button class="jumpbtn" data-jump="win">↗ Пік у ЖБ</button>
          ${(e.withdrawn||0)>0?`<button class="jumpbtn" data-jump="withdraw">↗ Вивід</button>`:''}</span>
          <span class="contextlinks"><button class="contextbtn" data-context="negative">Негатив</button><button class="contextbtn" data-context="games">Ігри</button></span>
        </div>
        ${e.waves&&e.waves.length>1?`<div class="waves">
          <div class="wavestitle">Окремі підйоми в межах цього депозиту</div>
          ${e.waves.map((w,i)=>`<div class="wave ${w.technical?'wave-tech':''}">
            <div class="waveidx">#${i+1}</div>
            <div class="waveinfo">
              <div class="wavetime">${fmtDate(w.peakTime)}</div>
              <div class="wavegame">${w.game?gameName(w.game):(w.technical?'Технічна активність':'—')}</div>
              <div class="wavedetails">
                ${w.winAmount>0?`WIN: <b>${MONEY.format(w.winAmount)} грн</b>`:'WIN: —'}
                · Ставка: <b>${w.betAmount?`${MONEY.format(w.betAmount)} грн`:'—'}</b>
                · Баланс: <b>${MONEY.format(w.peakBalance)} грн</b>
              </div>
              ${!w.technical && w.game?`<button class="wavecopy" data-wave="${i}">💬 Скопіювати текст</button>`:''}
            </div>
            <div class="waveratio">x${w.ratio.toFixed(2)}</div>
          </div>`).join('')}
          <div class="wavesummary">Новий підйом рахується після того, як баланс опустився нижче x2 і знову перетнув x2. Для піку показуються WIN, пов'язана ставка та баланс.</div>
        </div>`:''}
      </div>`;

      c.querySelector('.copy').onclick=async ev=>{
        try{
          await navigator.clipboard.writeText(copyText(e));
          setCopiedState(ev.currentTarget,'📋 Скопіювати',1400);
        }catch{
          ev.currentTarget.textContent='Не вдалося скопіювати';
        }
      };
      c.querySelectorAll('.jumpbtn').forEach(jb=>jb.onclick=(ev)=>{
        ev.preventDefault();
        ev.stopPropagation();
        const kind=jb.dataset.jump;
        if(kind==='deposit')jumpToJournalRow(e.depTime||e.startTime,'deposit');
        else if(kind==='win')jumpToJournalRow(e.peakTime,'win');
        else jumpToJournalRow(e.withdrawTime||e.lastWithdrawTime,'withdraw');
      });
      const wb=c.querySelector('.wavesbtn');
      if(wb){
        wb.onclick=()=>{
          const box=c.querySelector('.waves');
          const opened=box.classList.toggle('open');
          wb.textContent=opened?`↟ Сховати підйоми`:`↕ Підйоми x2+ (${e.waves.length})`;
        };
      }

      c.querySelectorAll('.wavecopy').forEach(btn=>{
        btn.onclick=async ()=>{
          const i=Number(btn.dataset.wave);
          const w=e.waves?.[i];
          if(!w)return;
          const x=compactX(w.ratio);
          const game=gameName(w.game);
          const bet=w.betAmount?` зі ставкою ${MONEY.format(w.betAmount)} грн`:'';
          const win=w.winAmount>0?`${MONEY.format(w.winAmount)} грн`:'—';
          const balance=MONEY.format(w.peakBalance);
          const text=`Х${x} у грі ${game}${bet} — виграш склав ${win}, баланс після нього — ${balance} грн`;
          try{
            await navigator.clipboard.writeText(text);
            setCopiedState(btn,'💬 Скопіювати текст',1400);
          }catch{
            btn.textContent='Не вдалося';
          }
        };
      });

      c.querySelectorAll('.contextbtn').forEach(btn=>{
        btn.onclick=()=>{
          const tab=btn.dataset.context;
          activateTab(root,tab,r,m,{skipRestore:true});
          if(tab==='negative'){
            requestAnimationFrame(()=>{
              const target=[...root.querySelectorAll('.moment')].find(x=>x.dataset.depositId===String(e.id||''));
              if(target){target.classList.add('context-highlight');target.scrollIntoView({block:'center',behavior:'smooth'});setTimeout(()=>target.classList.remove('context-highlight'),1800)}
            });
          }
          if(tab==='games' && e.game){
            requestAnimationFrame(()=>{
              const target=[...root.querySelectorAll('.gamecard')].find(x=>x.dataset.game===String(e.game));
              if(target){target.classList.add('context-highlight');target.scrollIntoView({block:'center',behavior:'smooth'});setTimeout(()=>target.classList.remove('context-highlight'),1800)}
            });
          }
        };
      });
      cards.appendChild(c);
    });
  }

  draw();
  const compactBtn=body.querySelector('.compactbtn');
  const applyCompact=()=>{
    const on=root.dataset.compact==='1';
    body.classList.toggle('compact-mode',on);
    compactBtn.textContent=on?'▦ Детально':'▤ Компактно';
  };
  compactBtn.onclick=()=>{
    root.dataset.compact=root.dataset.compact==='1'?'0':'1';
    applyCompact();
  };
  applyCompact();
  body.querySelector('.sort').onchange=e=>{
    const currentScroll=body.scrollTop;
    draw(e.target.value,activeRange);
    body.scrollTop=currentScroll;
  };
  body.querySelectorAll('.filterbtn').forEach(btn=>{
    btn.onclick=()=>{
      activeRange=btn.dataset.range;
      body.querySelectorAll('.filterbtn').forEach(b=>b.classList.toggle('active',b===btn));
      draw(body.querySelector('.sort').value,activeRange);
    };
  });

  body.querySelectorAll('.periodbtn').forEach(btn=>{
    btn.onclick=async()=>{
      const days=Number(btn.dataset.days);
      if(Number(root.dataset.period ?? 14)===days)return;
      root.dataset.period=String(days);

      body.querySelectorAll('.periodbtn').forEach(b=>{
        b.classList.toggle('active',b===btn);
        b.disabled=true;
      });

      let load=body.querySelector('.ppa-period-loading');
      if(!load){
        load=document.createElement('div');
        load.className='ppa-period-loading';
        load.style.cssText='margin:8px 0;padding:8px 10px;border:1px solid #3b355c;border-radius:8px;background:#171326;color:#c9c1ff;font-size:10px';
        const periods=body.querySelector('.periods');
        periods?.insertAdjacentElement('afterend',load);
      }
      load.textContent='Оновлюю аналіз за вибраний період...';

      const res=await window.__PPA_ANALYZE__(m,{preferCache:true});
      if(!res?.ok){
        load.textContent='⚠ Не вдалося оновити: '+(res?.error||'невідома помилка');
        body.querySelectorAll('.periodbtn').forEach(b=>b.disabled=false);
      }
    };
  });
}



function gameFocusLevel(share){
  if(share>=60)return {label:'Дуже часто грає',cls:'focus-hot',icon:'🔥',highlight:true};
  if(share>=40)return {label:'Часто грає',cls:'focus-high',icon:'▲',highlight:true};
  return {label:'',cls:'',icon:'',highlight:false};
}
function gameOperatorText(g){
  const name=gameName(g.game);
  return `Помітив, що останнім часом ви досить часто обираєте гру ${name}. Якщо ця гра вже не приносить вам бажаних вражень, можу запропонувати декілька інших слотів для різноманітності. Бажаєте?`;
}

function isBonusPurchaseRow(x){
  const raw=[
    x?.details,
    x?.detailsJson,
    x?.description,
    x?.comment
  ].filter(Boolean).map(v=>typeof v==='string'?v:JSON.stringify(v)).join(' ').toLowerCase();

  return /(bonus\s*buy|buy\s*bonus|feature\s*buy|buy\s*feature|bonus\s*purchase|purchase\s*bonus|покупк[аи]\s*бонус|куп(ити|івля)\s*бонус|бонусн(а|ої)\s*(гра|гри))/i.test(raw);
}
function isBonusBalanceBet(x){
  const j=x?.detailsJson;
  const amount=j?.amount;
  if(!amount || typeof amount!=='object')return false;

  const real=Number(amount.real_amount);
  const bonus=Number(amount.bonus_amount);
  const total=Number(amount.amount);

  // Example from ЖБ:
  // amount:{real_amount:0, bonus_amount:50, amount:50}
  // This is a bet paid fully from bonus funds and must not enter Stakes analytics.
  if(Number.isFinite(real) && Number.isFinite(bonus)){
    if(real<=0 && bonus>0)return true;
    if(Number.isFinite(total) && total>0 && bonus>=total && real<=0)return true;
  }
  return false;
}
function isServiceGameName(v){
  const s=String(v||'').trim().toLowerCase();
  return s==='club-millionaires'||s.includes('club-millionaires')||s==='vegas-heist'||s.includes('vegas-heist');
}
function depositBetCycles(){
  const all=rows().sort((a,b)=>a.date-b.date);
  const now=new Date(),cut=new Date(now-14*86400000);
  const depIdx=all.map((x,i)=>x.type==='deposit'?i:-1).filter(i=>i>=0);
  const cycles=[];

  for(let d=0;d<depIdx.length;d++){
    const si=depIdx[d], dep=all[si];
    if(dep.date<cut||dep.date>now)continue;
    const ei=d+1<depIdx.length?depIdx[d+1]:all.length;
    const amount=Math.abs(Number(dep.amount||0));
    if(!(amount>0))continue;
    const segment=all.slice(si+1,ei);
    const bets=segment.filter(x=>x.type==='bet' && x.game && !isExcludedFromGamesStats(x) && !isServiceGameName(x.game) && !isBonusPurchaseRow(x) && !isBonusBalanceBet(x));
    if(!bets.length)continue;
    const values=bets.map(x=>Math.abs(Number(x.amount||0))).filter(x=>x>0&&Number.isFinite(x));
    if(!values.length)continue;
    const total=values.reduce((a,b)=>a+b,0), max=Math.max(...values), min=Math.min(...values), avg=total/values.length;
    const highThreshold=amount*.05;
    const highBets=values.filter(v=>v>=highThreshold);
    const last=segment[segment.length-1]||bets[bets.length-1];
    const endBalance=Number.isFinite(Number(last?.balance))?Number(last.balance):null;
    const withdrawals=segment.filter(x=>x.type==='withdrawal');
    const withdrawn=withdrawals.reduce((z,x)=>z+Math.abs(Number(x.amount||0)),0);
    const topGames=new Map();
    bets.forEach(b=>topGames.set(b.game,(topGames.get(b.game)||0)+1));
    const topGame=[...topGames.entries()].sort((a,b)=>b[1]-a[1])[0];
    cycles.push({
      id:dep.depositId||'—', depositAmount:amount, depositTime:dep.date,
      endTime:last?.date||bets[bets.length-1].date, endBalance, withdrawn,
      count:values.length,total,avg,max,min,highCount:highBets.length,
      maxPct:max/amount*100,avgPct:avg/amount*100,
      firstBet:bets[0].date,lastBet:bets[bets.length-1].date,
      topGame:topGame?.[0]||'',topGameCount:topGame?.[1]||0,
      crossedDay:(last?.date&&dep.date&&last.date.toDateString()!==dep.date.toDateString())
    });
  }
  return cycles.sort((a,b)=>b.depositTime-a.depositTime);
}
function renderBets(root,r){
  const body=root.querySelector('.body'); if(!body)return;
  const cycles=depositBetCycles();
  const totalBets=cycles.reduce((z,x)=>z+x.count,0);
  body.innerHTML=`<div class="betsintro">Ставки тепер рахуються від конкретного депозиту до наступного депозиту. Якщо гра перейшла через північ, Player Insight продовжує той самий депозитний цикл.</div>
    <div class="betssummary"><b>${cycles.length}</b><span>депозитних циклів · ${totalBets} ставок</span></div>
    <div class="betslist"></div>`;
  const list=body.querySelector('.betslist');
  if(!cycles.length){list.innerHTML='<div class="emptybets">Ставок після депозитів у доступних даних не знайдено.</div>';return;}

  cycles.slice(0,50).forEach(x=>{
    const card=document.createElement('div');card.className='betcard deposit-bet-cycle';
    const level=x.maxPct>=25?'Дуже високі':x.maxPct>=10?'Високі':x.maxPct>=5?'Помітні':'Звичайні';
    const levelCls=x.maxPct>=25?'bet-danger':x.maxPct>=10?'bet-high':x.maxPct>=5?'bet-mid':'bet-normal';
    const continued=x.crossedDay?' · продовжено наступного дня':'';
    card.innerHTML=`<div class="bethead">
      <div><b>Депозит ${MONEY.format(x.depositAmount)} грн</b><span>${fmtDate(x.depositTime)}${continued}</span></div>
      <strong class="${levelCls}">${level}</strong>
    </div>
    <div class="depositbetstats">
      <div><span>Кількість ставок</span><b>${x.count}</b></div>
      <div><span>Сума ставок</span><b>${MONEY.format(x.total)} грн</b></div>
      <div><span>Середня ставка</span><b>${MONEY.format(x.avg)} грн</b><small>${x.avgPct.toFixed(1)}% депозиту</small></div>
      <div><span>Макс. ставка</span><b>${MONEY.format(x.max)} грн</b><small>${x.maxPct.toFixed(1)}% депозиту</small></div>
      <div><span>Високі ставки ≥5%</span><b>${x.highCount}</b></div>
      <div><span>Топ-гра</span><b>${x.topGame?gameName(x.topGame):'—'}</b><small>${x.topGameCount} ставок</small></div>
    </div>
    <div class="betcycleflow"><span>Період гри після депозиту</span><b>${fmtDate(x.firstBet)} → ${fmtDate(x.lastBet)}</b></div>
    <div class="betcycleflow"><span>Що сталося з коштами</span><b>${x.withdrawn>0?`Виведено ${MONEY.format(x.withdrawn)} грн`:Number.isFinite(x.endBalance)?`Останній баланс ${MONEY.format(x.endBalance)} грн`:'Немає даних про фінальний баланс'}</b></div>
    <div class="betactions"><button class="betcopy">💬 Текст для чату</button><button class="betjump">↗ Депозит у ЖБ</button></div>`;

    const text=`Звернув увагу, що після депозиту ${MONEY.format(x.depositAmount)} грн ви зробили ${x.count} ставок. Середня ставка — ${MONEY.format(x.avg)} грн, максимальна — ${MONEY.format(x.max)} грн (${x.maxPct.toFixed(1)}% від суми депозиту). Підкажіть, ви зазвичай граєте з таким розміром ставок?`;
    card.querySelector('.betcopy').onclick=async ev=>{try{await navigator.clipboard.writeText(text);ev.currentTarget.textContent='✓ Скопійовано';setTimeout(()=>ev.currentTarget.textContent='💬 Текст для чату',1400)}catch{ev.currentTarget.textContent='Не вдалося скопіювати'}};
    card.querySelector('.betjump').onclick=()=>{const panel=root.querySelector('.panel');if(panel)panel.style.display='none';root.classList.add('collapsed');setTimeout(()=>jumpToJournalRow(x.depositTime,'deposit'),180)};
    list.appendChild(card);
  });
}

function renderGames(root,r){
  const body=root.querySelector('.body'),s=gameStats();
  body.innerHTML=`<div class="gamesIntro">Ігри відсортовані за кількістю ставок за останні 14 днів. Так можна швидко побачити, у що гравець грає найчастіше.</div>
  <div class="stats"><div class="stat"><b>${s.totalGames}</b><span>різних ігор</span></div><div class="stat"><b>${s.totalBets}</b><span>ставок усього</span></div><div class="stat"><b>${s.games.find(g=>!g.isClubMillionaires)?Math.round(s.games.find(g=>!g.isClubMillionaires).share)+'%':'—'}</b><span>частка топ-гри</span></div></div>
  <div class="gamecards"></div>`;
  const box=body.querySelector('.gamecards');
  if(!s.games.length){box.innerHTML='<div class="empty">Ігрових ставок у завантаженій історії не знайдено.</div>';return}
  let rankedPosition=0;
  s.games.slice(0,20).forEach((g,i)=>{
    const c=document.createElement('div');c.className='gamecard';c.dataset.game=String(g.game||'');
    if(g.isSpecialActivity){
      c.classList.add('club-millionaires-card','special-activity-card');
      c.innerHTML=`<div class="clubtag">${specialActivityLabel(String(g.game||'').trim().toLowerCase())}</div>
      <div class="gamehead"><div><div class="gamename">${gameName(g.game)}</div><div class="gamepos">Окремо від рейтингу топ-ігор</div></div></div>
      <div class="gamegrid clubgrid"><div class="gstat"><b>${g.bets}</b><span>ставок</span></div><div class="gstat"><b>${MONEY.format(g.wagered)} грн</b><span>сума ставок</span></div></div>`;
      box.appendChild(c);
      return;
    }
    rankedPosition += 1;
    const vol=volatilityFor(g.game);
    c.innerHTML=`<div class="gamehead"><div><div class="gamepos">#${rankedPosition} · ${g.provider||'провайдер не вказаний'}</div><div class="gamename">${gameName(g.game)}</div></div><div class="share">${g.share.toFixed(1)}%</div></div>
    <div class="bar"><div class="barin" style="width:${Math.max(2,Math.min(100,g.share))}%"></div></div>
    <div class="gamegrid"><div class="gstat"><b>${g.bets}</b><span>ставок</span></div><div class="gstat"><b>${MONEY.format(g.wagered)} грн</b><span>сума ставок</span></div><div class="gstat"><b>${MONEY.format(g.maxBet)} грн</b><span>макс. ставка</span></div><div class="gstat"><b>${MONEY.format(g.maxWin)} грн</b><span>макс. WIN</span></div><div class="gstat x2stat"><b>${(r?.episodes||[]).filter(e=>String(e.game||'')===String(g.game||'')).length}</b><span>x2+ піків депозитів</span></div></div>
    
    ${vol?`<div class="volsrc">Джерело: ${vol.source}</div>`:''}
    ${(()=>{const f=gameFocusLevel(g.share);return f.highlight
      ? `<div class="focusbox"><div class="focusleft">Частота гри<br>${g.bets} із ${s.totalBets} ставок</div><div class="focusright ${f.cls}">${f.icon} ${f.label}<br>${g.share.toFixed(1)}%</div></div>`
      : `<div class="focusbox"><div class="focusleft">Частка ставок<br>${g.bets} із ${s.totalBets}</div><div class="focusright">${g.share.toFixed(1)}%</div></div>`})()}
    <button class="smallbtn gamecopy">📋 Назва</button><button class="smallbtn copyoperator">💬 Текст для чату</button>`;
    c.querySelector('.gamecopy').onclick=async ev=>{
      try{await navigator.clipboard.writeText(gameName(g.game));ev.currentTarget.textContent='✓';setTimeout(()=>ev.currentTarget.textContent='📋 Назва',900)}
      catch{ev.currentTarget.textContent='Не вдалося скопіювати'}
    };
    c.querySelector('.copyoperator').onclick=async ev=>{
      try{
        await navigator.clipboard.writeText(gameOperatorText(g));
        setCopiedState(ev.currentTarget,'💬 Текст для чату',1400);
      }catch{ev.currentTarget.textContent='Не вдалося скопіювати'}
    };
    box.appendChild(c);
  });
}


function negativeMoments(r){
  return [...r.episodes]
    .filter(e=>e.ratio>=2)
    .map(e=>{
      const withdrew=Number(e.withdrawn||0);
      const end=Number(e.endBal||0);
      const peak=Number(e.peak||0);
      const deposit=Number(e.amt||0);
      const profit=Math.max(0,peak-deposit);
      const withdrewMost = withdrew>0 && (withdrew>=peak*0.7 || (profit>0 && withdrew>=profit));
      const partial = withdrew>0 && !withdrewMost;
      const spent = !withdrew && !!e.lost;
      let kind='unknown',label='Недостатньо даних',cls='neg-mid';
      if(withdrewMost){kind='fixed';label='✓ Виведено значну частину або весь результат';cls='neg-good'}
      else if(partial){kind='partial';label=`▲ Частково виведено: ${MONEY.format(withdrew)} грн`;cls='neg-mid'}
      else if(spent){kind='spent';label='✕ Баланс витрачено без виведення коштів';cls='neg-bad'}
      return {...e,withdrew,end,peak,deposit,profit,kind,label,cls};
    })
    .filter(e=>e.kind==='spent'||e.kind==='partial'||e.kind==='fixed')
    .sort((a,b)=>{
      const priority={spent:0,partial:1,unknown:2,fixed:3};
      return priority[a.kind]-priority[b.kind] || b.ratio-a.ratio;
    });
}

function momentChatText(e){
  const dep=MONEY.format(e.deposit);
  const peak=MONEY.format(e.peak);

  if(e.kind==='partial'){
    return `Помітив, що сьогодні ви зробили депозит на суму ${dep} грн та збільшили баланс до ${peak} грн. Ви вивели ${MONEY.format(e.withdrew)} грн, а з рештою коштів продовжили гру. Підкажіть, будь ласка, що вплинуло на рішення продовжити гру?`;
  }

  if(e.kind==='spent'){
    return `Помітив, що сьогодні ви зробили депозит на суму ${dep} грн та змогли збільшити баланс до ${peak} грн. Надалі ви продовжили гру, не здійснивши виведення коштів. Підкажіть, будь ласка, чи розглядали ви можливість завершити гру та зафіксувати цей результат?`;
  }

  if(e.kind==='fixed'){
    return `Помітив, що сьогодні ви зробили депозит на ${dep} грн та збільшили баланс до ${peak} грн. Ви вивели ${MONEY.format(e.withdrew)} грн, а з рештою коштів продовжили гру. Чи правильно розумію, що попри цей результат ви все одно відчули, що гра не дала очікуваної віддачі?`;
  }

  return `Помітив, що після депозиту на суму ${dep} грн ваш баланс зріс до ${peak} грн.`;
}
function renderNegative(root,r){
  const body=root.querySelector('.body');
  if(!body)return;

  const moments=negativeMoments(r);
  const pct=e=>{
    const peak=Number(e.peak||0);
    const out=Number(e.withdrew||0);
    return peak>0?(out/peak)*100:0;
  };

  const counts={
    none:moments.filter(e=>Number(e.withdrew||0)<=0).length,
    partial:moments.filter(e=>pct(e)>0&&pct(e)<70).length,
    significant:moments.filter(e=>pct(e)>=70).length
  };

  body.innerHTML=`
    <div class="negintro">Ключові x2+ моменти для роботи зі зверненнями про програш або відсутність віддачі. Невизначені кейси тут не показуються.</div>
    <div class="neg-category-grid">
      <div class="negbox"><b>${counts.none}</b><span class="neg-label">Не вивів</span><small class="neg-badge">0%</small></div>
      <div class="negbox"><b>${counts.partial}</b><span class="neg-label">Частковий вивід</span><small class="neg-badge">1–69%</small></div>
      <div class="negbox"><b>${counts.significant}</b><span class="neg-label">Значний / повний вивід</span><small class="neg-badge">70%+</small></div>
    </div>
    <div class="moments"></div>`;

  const box=body.querySelector('.moments');
  if(!moments.length){
    box.innerHTML='<div class="negsection"><div class="negline">Підйомів x2+ у завантаженій історії не знайдено.</div></div>';
    return;
  }

  moments.forEach(e=>{
    const card=document.createElement('div');
    card.className='moment';
    card.dataset.depositId=String(e.id||'');
    const game=e.game?gameName(e.game):'—';
    card.innerHTML=`<div class="momenthead"><div><div class="momentdate">${fmtDate(e.peakTime)}</div><div>${game}</div></div><div class="momentx">x${compactX(e.ratio)}</div></div>
      <div class="momentflow">${MONEY.format(e.deposit)} → ${MONEY.format(e.peak)} грн</div>
      <div class="momentmeta">
        <span>ID депозиту</span><span>${e.id||'—'}</span>
        <span>Баланс на піку</span><span>${MONEY.format(e.peak)} грн</span>
        <span>Виведено після піку</span><span>${e.withdrew>0?MONEY.format(e.withdrew)+' грн':'0 грн'}</span>
        <span>Баланс наприкінці</span><span>${MONEY.format(e.end)} грн</span>
        <span>Окремих підйомів x2+</span><span>${e.waves?.length||1}</span>
      </div>
      <div class="momenttag ${e.cls}">${e.label}</div>
      <button class="momentcopy">💬 Скопіювати текст для чату</button>`;

    card.querySelector('.momentcopy').onclick=async ev=>{
      try{
        await navigator.clipboard.writeText(momentChatText(e));
        ev.currentTarget.textContent='✓ Скопійовано';
        setTimeout(()=>ev.currentTarget.textContent='💬 Скопіювати текст для чату',1400);
      }catch{
        ev.currentTarget.textContent='Не вдалося скопіювати';
      }
    };
    box.appendChild(card);
  });
}

function quickReplyData(r){
  const eps=[...(r.episodes||[])];
  const games=gameStats();
  const topGame=games.games?.[0]||null;

  const best=[...eps].sort((a,b)=>b.ratio-a.ratio)[0]||null;
  const lost=[...eps].filter(e=>e.lost&&!e.withdrawn).sort((a,b)=>b.ratio-a.ratio)[0]||null;
  const partial=[...eps].filter(e=>(e.withdrawn||0)>0 && (e.withdrawn||0)<(e.peak||0)*0.7).sort((a,b)=>b.ratio-a.ratio)[0]||null;
  const fixed=[...eps].filter(e=>(e.withdrawn||0)>0 && ((e.withdrawn||0)>=(e.peak||0)*0.7 || (e.withdrawn||0)>=Math.max(0,(e.peak||0)-(e.amt||0)))).sort((a,b)=>b.ratio-a.ratio)[0]||null;

  return {best,lost,partial,fixed,topGame};
}

function buildQuickReply(type,r){
  const d=quickReplyData(r);
  const f=n=>MONEY.format(Number(n||0));

  if(type==='return'){
    const e=d.fixed||d.partial||d.best;
    if(!e)return {text:'Недостатньо даних для формування відповіді.',note:'Не знайдено відповідного x2+ епізоду.'};

    if((e.withdrawn||0)>0){
      return {
        text:`Помітив, що сьогодні ви зробили депозит на ${f(e.amt)} грн та збільшили баланс до ${f(e.peak)} грн. Ви вивели ${f(e.withdrawn)} грн, а з рештою коштів продовжили гру. Чи правильно розумію, що попри цей результат ви все одно відчули, що гра не дала очікуваної віддачі?`,
        note:`Використано кейс x${compactX(e.ratio)} з виводом ${f(e.withdrawn)} грн.`
      };
    }

    return {
      text:`Помітив, що після депозиту на ${f(e.amt)} грн ваш баланс зростав до ${f(e.peak)} грн. Підкажіть, будь ласка, що саме ви маєте на увазі під відсутністю віддачі?`,
      note:`Використано найсильніший доступний підйом x${compactX(e.ratio)}.`
    };
  }

  if(type==='lost'){
    const e=d.lost||d.partial||d.best;
    if(!e)return {text:'Недостатньо даних для формування відповіді.',note:'Не знайдено відповідного депозитного циклу.'};

    if(e.lost){
      return {
        text:`Помітив, що сьогодні ви зробили депозит на ${f(e.amt)} грн та змогли збільшити баланс до ${f(e.peak)} грн. Надалі ви продовжили гру, не здійснивши виведення коштів. Підкажіть, будь ласка, чи розглядали ви можливість завершити гру та зафіксувати цей результат?`,
        note:`Використано кейс без виводу, де баланс було витрачено до наступного депозиту.`
      };
    }

    return {
      text:`Помітив, що після депозиту на ${f(e.amt)} грн баланс зростав до ${f(e.peak)} грн. Підкажіть, будь ласка, на якому етапі ви відчули, що гра перестала давати очікуваний результат?`,
      note:`Використано найбільш релевантний доступний x2+ кейс.`
    };
  }

  if(type==='cantwin'){
    const e=d.best;
    if(!e)return {text:'Недостатньо даних для формування відповіді.',note:'Підйомів x2+ не знайдено.'};
    return {
      text:`Перевірив вашу ігрову активність. Помітив, що після депозиту на ${f(e.amt)} грн баланс піднімався до ${f(e.peak)} грн, тобто приблизно x${compactX(e.ratio)} від суми депозиту. Підкажіть, будь ласка, що саме ви маєте на увазі, коли говорите, що не вдається виграти?`,
      note:`Використано найкращий знайдений підйом за останні 14 днів.`
    };
  }

  if(type==='onegame'){
    const g=d.topGame;
    if(!g)return {text:'Недостатньо даних для формування відповіді.',note:'Не знайдено ігрової активності.'};
    return {
      text:`Помітив, що останнім часом ви досить часто обираєте гру ${gameName(g.game)} — на неї припадає близько ${g.share.toFixed(1)}% ваших ставок. Якщо хочете різноманітності, можу запропонувати декілька інших слотів. Бажаєте?`,
      note:`${g.bets} ставок у ${gameName(g.game)} · ${g.share.toFixed(1)}% від усіх ставок.`
    };
  }

  return {text:'Оберіть тип звернення.',note:''};
}

function renderQuickReply(root,r){
  const body=root.querySelector('.body');
  body.innerHTML=`<div class="reply-intro">Оберіть причину звернення — Player Insight підставить релевантні факти з історії гравця та підготує текст для чату.</div>
    <div class="reply-types">
      <button class="reply-type active" data-reply="return">Немає віддачі</button>
      <button class="reply-type" data-reply="lost">Все програв</button>
      <button class="reply-type" data-reply="cantwin">Не можу виграти</button>
      <button class="reply-type" data-reply="onegame">Часто одна гра</button>
    </div>
    <div class="reply-card">
      <div class="reply-label">Готовий текст</div>
      <div class="reply-text"></div>
      <div class="reply-note"></div>
      <div class="reply-actions"><button class="reply-copy">💬 Текст для чату</button></div>
    </div>`;

  let current='return';
  const textEl=body.querySelector('.reply-text');
  const noteEl=body.querySelector('.reply-note');
  const copyBtn=body.querySelector('.reply-copy');

  const refresh=()=>{
    const q=buildQuickReply(current,r);
    textEl.textContent=q.text;
    noteEl.textContent=q.note||'';
  };

  body.querySelectorAll('.reply-type').forEach(btn=>{
    btn.onclick=()=>{
      current=btn.dataset.reply;
      body.querySelectorAll('.reply-type').forEach(b=>b.classList.toggle('active',b===btn));
      refresh();
      animateSection(root);
    };
  });

  copyBtn.onclick=async ()=>{
    const q=buildQuickReply(current,r);
    try{
      await navigator.clipboard.writeText(q.text);
      setCopiedState(copyBtn,'💬 Текст для чату',1400);
    }catch{
      copyBtn.textContent='Не вдалося скопіювати';
    }
  };

  refresh();
}


function ppaNormText(v=''){
  return String(v||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
}
function ppaFindValueByTh(label){
  const wanted=ppaNormText(label).toLowerCase();
  for(const th of document.querySelectorAll('th')){
    if(ppaNormText(th.textContent).toLowerCase()===wanted){
      return ppaNormText(th.parentElement?.querySelector('td')?.textContent||'');
    }
  }
  return '';
}
function ppaHasManagerCardData(){
  return !!(
    ppaFindValueByTh('Ответственный VIP-менеджер') ||
    ppaFindValueByTh('Номер ответственного VIP-менеджера') ||
    document.querySelector('[data-toggle-comments-item] textarea[data-comment-edit]')
  );
}
function ppaClassifyManagerContact(text=''){
  const t=(' '+String(text||'').toLowerCase().replace(/ё/g,'е').replace(/[–—]/g,'-').replace(/\s+/g,' ')+' ');
  const success=[/\bвідповів(ла|)\b/,/\bответил(а|)\b/,/\bпоговорил(и|а|)\b/,/\bпоспілкувал(ися|ась|ся)\b/,/\bсозвонил(ись|ась|ся)\b/,/\bна зв'язку\b/,/\bна связи\b/,/\bвзяв(ла|) слухавку\b/,/\bвзял(а|) трубку\b/,/\bдомовил(ись|ась|ся)\b/,/\bдоговорил(ись|ась|ся)\b/,/\bпише\b/,/\bпишет\b/,/\bвідпис(ав|ала|ує)\b/,/\bответил(а|) в (тг|чат)\b/];
  if(success.some(rx=>rx.test(t)))return {kind:'ok',label:'Контакт був'};
  const fail=[/(^|[\s,;:/()\-])нв($|[\s,;:.!?/()\-])/,/(^|[\s,;:/()\-])ао($|[\s,;:.!?/()\-])/,/\bнемає відповіді\b/,/\bнет ответа\b/,/\bбез відповіді\b/,/\bне відповіда(є|в|ла)\b/,/\bне отвечает\b/,/\bне підня(в|ла)\b/,/\bне подня(л|ла)\b/,/\bне взя(л|ла)\b/,/\bне бере слухавку\b/,/\bне берет трубку\b/,/\bне додзвони(вся|лась|лася)\b/,/\bне дозвони(лся|лась|лась)\b/,/\bавтовідповідач\b/,/\bавтоответчик\b/,/\bскину(в|ла)\b/,/\bсброс(ил|ила|)\b/,/\bвідхили(в|ла) дзвінок\b/,/\bгудки\b.*\bскид\b/,/\bгудки\b/];
  if(fail.some(rx=>rx.test(t)))return {kind:'fail',label:'Без контакту'};
  return {kind:'neutral',label:'Інше'};
}
function ppaManagerSignals(text=''){
  const t=(' '+String(text||'').toLowerCase().replace(/ё/g,'е').replace(/[–—]/g,'-').replace(/\s+/g,' ')+' ');
  const detach=[/\+\s*откреп/,/\bоткреп(ил|ила|лен|лена|ить|)\b/,/\bвідкріп(ив|ила|лено|ити|)\b/,/\bотвяз(ал|ала|ан|ать)\b/,/\bномер\b.{0,25}\b(откреп|відкріп|отвяз)\b/];
  const offer=[/предлаг(ать|ай|аем|ати).{0,35}(звон|дзвін|связ|зв'яз).{0,35}менедж/,/звон(ок|ка).{0,25}(с|з).{0,15}менедж/,/зв'яз(ок|ку).{0,25}(з|із).{0,15}менедж/,/связ(ь|и).{0,25}(с|з).{0,15}менедж/];
  const blocked=[/лист.{0,12}номер.{0,12}блок/,/номер.{0,20}блок/,/заблокирован.{0,15}номер/,/номер.{0,15}заблокован/];
  return {detached:detach.some(rx=>rx.test(t)),offerManager:offer.some(rx=>rx.test(t)),numberBlocked:blocked.some(rx=>rx.test(t))};
}
function ppaPhoneConfirmationState(){
  const labels=['Тел. підтверджений','Тел. подтвержденный','Тел. подтвержден','Телефон підтверджений','Телефон подтвержден'];
  for(const th of document.querySelectorAll('th')){
    const label=ppaNormText(th.textContent).toLowerCase();
    if(!labels.some(x=>label===x.toLowerCase()))continue;
    const row=th.closest('tr')||th.parentElement;
    const text=ppaNormText(row?.textContent||'').toLowerCase();
    const buttons=[...(row?.querySelectorAll('button,input[type="button"],input[type="submit"],a')||[])];
    const confirm=buttons.find(el=>/подтверд|підтверд/.test(ppaNormText(el.textContent||el.value||'').toLowerCase()));
    return {found:true,needsConfirmation:!!confirm || /подтвердить|підтвердити/.test(text),label:ppaNormText(th.textContent),buttonText:confirm?ppaNormText(confirm.textContent||confirm.value||''):''};
  }
  return {found:false,needsConfirmation:false,label:'',buttonText:''};
}
function ppaManagerAssignment(raw=''){
  const original=ppaNormText(raw);
  const t=original
    .toLowerCase()
    .replace(/ё/g,'е')
    .replace(/[–—]/g,'-')
    .replace(/[.,;:!?()[\]{}"'’`]+/g,' ')
    .replace(/\s+/g,' ')
    .trim();

  // IMPORTANT: do not use JS \b here. For Cyrillic/Ukrainian text JavaScript
  // word boundaries are unreliable because \b is based on ASCII \w.
  const noManagerPhrases=[
    'отказ от игры','відмова від гри',
    'для вывода на контакт','для виводу на контакт',
    'вывод на контакт','вивід на контакт',
    'дальний ящик','дальній ящик',
    'нет контакта','немає контакту',
    'без контакта','без контакту',
    'не звонить','не дзвонити',
    'отказ менеджера','відмова менеджера'
  ];

  if(!original){
    return {hasManager:false,status:'Менеджер не призначений',raw:original,reason:'empty'};
  }

  const matched=noManagerPhrases.find(phrase=>t.includes(phrase));
  if(matched){
    return {hasManager:false,status:original,raw:original,reason:'service_status',matched};
  }

  return {hasManager:true,status:'',raw:original,reason:'assigned'};
}
function ppaReadManagerCard(){
  const manager=ppaFindValueByTh('Ответственный VIP-менеджер');
  const assignment=ppaManagerAssignment(manager);
  const phone=assignment.hasManager?ppaFindValueByTh('Номер ответственного VIP-менеджера'):'';
  const comments=[...document.querySelectorAll('[data-toggle-comments-item]')].map((item,index)=>{
    const ta=item.querySelector('textarea[data-comment-edit]'); if(!ta)return null;
    const footer=item.querySelector('footer');
    const author=ppaNormText(footer?.querySelector('b')?.textContent||'');
    const footerText=ppaNormText(footer?.textContent||'');
    const dateText=ppaNormText(footerText.replace(author,'').split('(Изм.:')[0]);
    const text=String(ta.value||ta.textContent||'').trim();
    return {id:ta.getAttribute('data-comment-edit')||'',text,author,dateText,index,contact:ppaClassifyManagerContact(text),signals:ppaManagerSignals(text)};
  }).filter(Boolean);
  const latest3=comments.slice(0,3);
  const threeFailed=latest3.length===3 && latest3.every(c=>c.contact.kind==='fail');
  const latest=comments[0]||null;
  const phoneState=ppaPhoneConfirmationState();
  const detachComment=comments.find(c=>c.signals.detached)||null;
  const offerComment=comments.find(c=>c.signals.offerManager)||null;
  const blockedComment=comments.find(c=>c.signals.numberBlocked)||null;
  const phoneDetachFlow=!!(assignment.hasManager && phoneState.needsConfirmation && (detachComment||blockedComment));
  const shouldOfferManager=!!(assignment.hasManager && (threeFailed || phoneDetachFlow || offerComment));
  return {manager,assignment,phone,comments,latest3,threeFailed,latest,phoneState,detachComment,offerComment,blockedComment,phoneDetachFlow,shouldOfferManager};
}
function ppaEsc(v=''){
  return String(v).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}

function ppaManagerBonusUrl(){
  const direct=[...document.querySelectorAll('a[href*="/players/playersBonuses/assignedVipBonuses/"]')]
    .map(a=>a.getAttribute('href')||'').find(Boolean);
  if(direct)return new URL(direct,location.href).href;

  const candidates=[
    location.pathname,
    ...[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')||'')
  ];
  for(const value of candidates){
    const m=String(value).match(/\/(?:players\/playersItems\/(?:view|update|balanceLog)|players\/playersBonuses\/assignedVipBonuses)\/(\d+)/i);
    if(m)return new URL(`/players/playersBonuses/assignedVipBonuses/${m[1]}/`,location.origin).href;
  }
  return '';
}
function ppaBonusMoney(text=''){
  const m=String(text).replace(/\u00a0/g,' ').match(/(-?[\d\s]+(?:[.,]\d+)?)\s*(?:UAH|₴|грн)/i);
  if(!m)return null;
  const n=Number(m[1].replace(/\s/g,'').replace(',','.'));
  return Number.isFinite(n)?n:null;
}
function ppaBonusFs(text=''){
  const m=String(text).match(/(\d+)\s*FS\b/i);
  return m?Number(m[1]):0;
}
function ppaParseManagerBonuses(doc){
  const tables=[...doc.querySelectorAll('table')];
  const table=tables.find(t=>{
    const heads=[...t.querySelectorAll('thead th')].map(x=>ppaNormText(x.textContent).toLowerCase());
    return heads.some(x=>x.includes('id бонус')) &&
           heads.some(x=>x.includes('название бонус')) &&
           heads.some(x=>x.includes('статус'));
  });
  if(!table)return [];
  return [...table.querySelectorAll('tbody tr')].map(tr=>{
    const td=[...tr.querySelectorAll('td')];
    if(td.length<9)return null;
    const bonusText=ppaNormText(td[4]?.textContent||'');
    const resultText=ppaNormText(td[5]?.textContent||'');
    return {
      id:ppaNormText(td[0]?.textContent||''),
      name:ppaNormText(td[1]?.textContent||''),
      date:ppaNormText(td[2]?.textContent||''),
      deposit:ppaBonusMoney(td[3]?.textContent||''),
      bonus:ppaBonusMoney(bonusText),
      fs:ppaBonusFs(bonusText),
      resultText,
      wager:ppaNormText(td[6]?.textContent||''),
      btr:ppaBonusMoney(td[7]?.textContent||''),
      status:ppaNormText(td[8]?.textContent||'').toLowerCase()
    };
  }).filter(Boolean);
}
function ppaBonusStatus(status=''){
  const map={
    done:{label:'Завершено',cls:'done'},
    rejected:{label:'Відхилено',cls:'rejected'},
    rejected_by_expiration:{label:'Термін минув',cls:'expired'},
    canceled:{label:'Скасовано',cls:'canceled'}
  };
  return map[status]||{label:status||'—',cls:'other'};
}
function ppaFmtBonusMoney(v){
  if(v===null || !Number.isFinite(v))return '—';
  return new Intl.NumberFormat('uk-UA',{maximumFractionDigits:2}).format(v)+' грн';
}

function ppaPlayerIdFromUpdateUrl(){
  // IMPORTANT: /players/playersItems/update/<number>/ contains the internal player ID,
  // not the Login required by PlayersDetailForm[login].
  const vals=[location.pathname,...[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')||'')];
  for(const v of vals){
    const m=String(v).match(/\/players\/playersItems\/update\/(\d+)\/?/i);
    if(m)return m[1];
  }
  return '';
}
function ppaPlayerLoginFromCard(){
  // Both 777 and Vegas expose the REAL player Login in the copy marker:
  // data-for-copy="[9946803](https://admin.777.ua/players/playersItems/update/955901/)"
  // The number inside update/<...>/ is the internal player ID, NOT Login.
  for(const el of document.querySelectorAll('span.fa-files-o[data-for-copy], [data-for-copy]')){
    const copy=String(el.getAttribute('data-for-copy')||'').trim();
    if(!/\/players\/playersItems\/update\/\d+\/?/i.test(copy))continue;
    const m=copy.match(/^\s*\[(\d{3,})\]\s*\(/);
    if(m)return m[1];
    // Fallback for the same cell: first numeric span is Login.
    const td=el.closest('td');
    const first=td?.querySelector('span:not(.fa)');
    const raw=String(first?.textContent||'').trim();
    if(/^\d{3,}$/.test(raw))return raw;
  }

  // Fallback for a full player-card row such as:
  // <th>Номер гравця</th><td><span>5449100</span>...</td>
  const labels=['login','логин','логін','номер гравця','номер игрока'];
  for(const th of document.querySelectorAll('th')){
    const label=ppaNormText(th.textContent).toLowerCase().replace(/[:*]+$/,'').trim();
    if(labels.includes(label)){
      const td=th.parentElement?.querySelector('td');
      const marker=td?.querySelector('[data-for-copy]');
      const copy=String(marker?.getAttribute('data-for-copy')||'');
      const cm=copy.match(/^\s*\[(\d{3,})\]\s*\(/);
      if(cm)return cm[1];
      const raw=ppaNormText(td?.querySelector('span')?.textContent||td?.textContent||'');
      const m=raw.match(/\b(\d{3,})\b/);
      if(m)return m[1];
    }
  }

  for(const el of document.querySelectorAll('input[name*="login" i], input[id*="login" i]')){
    const raw=String(el.value||'').trim();
    if(/^\d{3,}$/.test(raw))return raw;
  }
  return '';
}
function ppaPlayerInternalId(){
  const vals=[location.pathname,...[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href')||'')];
  for(const v of vals){
    const m=String(v).match(/\/players\/playersBonuses\/assignedVipBonuses\/(\d+)\/?/i);
    if(m)return m[1];
  }
  return '';
}
async function ppaResolvePlayerLogin(){
  return ppaPlayerLoginFromCard();
}
function ppaParseBonusDate(text=''){
  const m=String(text).match(/(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2}):(\d{2}))?/);
  if(!m)return null;
  const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]),Number(m[4]||0),Number(m[5]||0),Number(m[6]||0));
  return Number.isNaN(d.getTime())?null:d;
}
function ppaIsNoDepositBonus(b){
  const noDeposit=(b.deposit===null || b.deposit<=0);
  const hasGrant=(Number(b.bonus)>0 || Number(b.fs)>0);
  const name=String(b.name||'').toLowerCase();
  return noDeposit && hasGrant && (/бездеп|без\s*деп|no\s*deposit/.test(name) || b.deposit===0);
}
function ppaBonusWasReceived(b){
  return !['rejected','rejected_by_expiration','canceled','cancelled'].includes(String(b.status||'').toLowerCase());
}
function ppaPad2(n){return String(n).padStart(2,'0');}
function ppaDetailDate(d){
  return `${d.getFullYear()}.${ppaPad2(d.getMonth()+1)}.${ppaPad2(d.getDate())} ${ppaPad2(d.getHours())}:${ppaPad2(d.getMinutes())}:${ppaPad2(d.getSeconds())}`;
}
function ppaShortDate(d){return `${ppaPad2(d.getDate())}.${ppaPad2(d.getMonth()+1)}.${d.getFullYear()}`;}
function ppaParseNumber(text=''){
  const n=Number(String(text).replace(/\u00a0/g,' ').replace(/[^\d,.-]/g,'').replace(',','.'));
  return Number.isFinite(n)?n:null;
}
function ppaDetailValue(doc,label){
  const wanted=String(label).toLowerCase();
  for(const th of doc.querySelectorAll('th')){
    if(ppaNormText(th.textContent).toLowerCase()===wanted){
      return ppaParseNumber(th.parentElement?.querySelector('td')?.textContent||'');
    }
  }
  return null;
}
async function ppaLoadManagerNetStats(items){
  const resolvedLogin=await ppaResolvePlayerLogin();
  if(!resolvedLogin)throw new Error('Не вдалося знайти Login гравця у data-for-copy на картці. ID з /playersItems/update/<ID>/ не використовується як Login.');
  const now=new Date();
  const monthStart=new Date(now.getFullYear(),now.getMonth(),1,0,0,0);
  const monthBonuses=items.map(b=>({b,d:ppaParseBonusDate(b.date)}))
    .filter(x=>x.d && x.d>=monthStart && x.d<=now && ppaIsNoDepositBonus(x.b))
    .sort((a,b)=>b.d-a.d);
  const latest=monthBonuses[0]||null;
  let from,threshold;
  if(latest){from=new Date(latest.d.getFullYear(),latest.d.getMonth(),latest.d.getDate()+1,0,0,0);threshold=10000;}
  else{from=monthStart;threshold=5000;}
  const till=new Date(now.getFullYear(),now.getMonth(),now.getDate(),23,59,59);
  const base='backend_modules_players_models_PlayersDetailForm';
  const login=resolvedLogin;
  // A no-deposit bonus counts from the moment it was assigned, regardless of its final status.
  // Statistics are intentionally calculated from the NEXT calendar day. If that day
  // has not started yet, do not send an inverted period to PlayersDetail.
  if(latest && from>till){
    return {login,from,till,deposits:null,redeems:null,net:null,threshold,latestBonus:latest.b,latestDate:latest.d,pendingNextDay:true};
  }
  try{
      const params=new URLSearchParams();
      params.append(`${base}[login]`,login);
      params.append(`${base}[period]`,`${ppaDetailDate(from)} - ${ppaDetailDate(till)}`);
      params.append(`${base}[partner]`,'');
      params.append(`${base}[show_table]`,'0'); params.append(`${base}[show_table]`,'1');
      params.append(`${base}[show_cash_back]`,'0'); params.append(`${base}[show_partner_stat]`,'0');
      params.append(`${base}[dv_real_only]`,'0'); params.append('yt0','');
      // Submit exactly like the native admin form, inside the CURRENT project origin.
      // This avoids cross-project requests and also avoids fetch/XHR routing differences.
      const endpoint=new URL('/players/playersDetail/index/',location.origin).href;
      const doc=await new Promise((resolve,reject)=>{
        const iframe=document.createElement('iframe');
        const frameName='ppa-detail-'+Date.now()+'-'+Math.random().toString(36).slice(2);
        iframe.name=frameName;
        iframe.style.cssText='position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;left:-9999px;top:-9999px;border:0';
        const form=document.createElement('form');
        form.method='POST'; form.action=endpoint; form.target=frameName;
        form.style.display='none';
        for(const [name,value] of params.entries()){
          const input=document.createElement('input'); input.type='hidden'; input.name=name; input.value=value; form.appendChild(input);
        }
        let done=false;
        const cleanup=()=>{setTimeout(()=>{form.remove();iframe.remove();},0)};
        const timer=setTimeout(()=>{if(done)return;done=true;cleanup();reject(new Error('таймаут запиту «Детально»'));},15000);
        iframe.addEventListener('load',()=>{
          if(done)return;
          try{
            const d=iframe.contentDocument;
            if(!d || !d.documentElement)return;
            const hasData=[...d.querySelectorAll('th')].some(th=>ppaNormText(th.textContent).toLowerCase()==='deposits total');
            const pageText=ppaNormText(d.body?.textContent||'');
            if(!hasData && !pageText)return;
            done=true; clearTimeout(timer);
            const cloned=new DOMParser().parseFromString(d.documentElement.outerHTML,'text/html');
            cleanup(); resolve(cloned);
          }catch(err){done=true;clearTimeout(timer);cleanup();reject(new Error('не вдалося прочитати відповідь «Детально»'));}
        });
        document.documentElement.appendChild(iframe);
        document.documentElement.appendChild(form);
        form.submit();
      });
      const deposits=ppaDetailValue(doc,'Deposits Total'), redeems=ppaDetailValue(doc,'Redeems Total');
      if(deposits===null || redeems===null)throw new Error('у відповіді немає Deposits Total / Redeems Total');
      return {login,from,till,deposits,redeems,net:deposits-redeems,threshold,latestBonus:latest?.b||null,latestDate:latest?.d||null};
  }catch(e){
    throw new Error('Не вдалося отримати статистику «Детально»: '+(e?.message||String(e)));
  }
}
function ppaRenderNetStats(s){
  const title=s.latestBonus?'Після останнього бездепу':'Цього місяця бездепу не було';
  if(s.pendingNextDay){
    return `<div class="manager-net-card">
      <div class="manager-net-head"><div><b>${ppaEsc(title)}</b><span>Останній бездеп: ${ppaEsc(ppaShortDate(s.latestDate))}</span></div><em>Дані: Детально</em></div>
      <div class="manager-net-basis">Останній бездеп призначено сьогодні. Статус бонусу не впливає на розрахунок. Новий період почнеться <b>${ppaEsc(ppaShortDate(s.from))}</b>.</div>
      <div class="manager-net-verdict wait">Поріг після бездепу: ${ppaEsc(ppaFmtBonusMoney(s.threshold))}. Даних за повний наступний день ще немає.</div>
    </div>`;
  }
  const enough=s.net>=s.threshold;
  const positiveForPlayer=s.net<0;
  const diff=Math.max(0,s.threshold-s.net);
  const basis=s.latestBonus
    ? `Останній бездеп: <b>${ppaEsc(ppaShortDate(s.latestDate))}</b> · розрахунок з наступного дня`
    : `Розрахунок з <b>1-го числа поточного місяця</b>`;
  let verdict;
  if(enough)verdict=`<div class="manager-net-verdict ok">✓ Мінус гравця від ${ppaFmtBonusMoney(s.threshold)}. Можна передати запит VIP-менеджеру щодо компліменту.</div>`;
  else if(positiveForPlayer)verdict=`<div class="manager-net-verdict no">Гравець у плюсі на ${ppaFmtBonusMoney(Math.abs(s.net))}. Поріг для запиту не виконано.</div>`;
  else verdict=`<div class="manager-net-verdict wait">До порогу повторного запиту не вистачає ${ppaFmtBonusMoney(diff)}.</div>`;
  return `<div class="manager-net-card">
    <div class="manager-net-head"><div><b>${ppaEsc(title)}</b><span>${ppaEsc(ppaShortDate(s.from))} — ${ppaEsc(ppaShortDate(s.till))}</span></div><em>Дані: Детально</em></div>
    <div class="manager-net-basis">${basis}</div>
    <div class="manager-net-grid"><div><span>Внесено</span><b>${ppaEsc(ppaFmtBonusMoney(s.deposits))}</b></div><div><span>Виведено</span><b>${ppaEsc(ppaFmtBonusMoney(s.redeems))}</b></div><div class="wide"><span>Фінансовий результат</span><b class="${s.net>=0?'loss':'plus'}">${s.net>=0?'−':'+'}${ppaEsc(ppaFmtBonusMoney(Math.abs(s.net)))}</b><small>Поріг: ${ppaEsc(ppaFmtBonusMoney(s.threshold))}</small></div></div>
    ${verdict}
  </div>`;
}
async function ppaLoadManagerBonuses(){
  const url=ppaManagerBonusUrl();
  if(!url)throw new Error('Не вдалося знайти посилання «Інфо по бонусах від менеджера».');
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),12000);
  try{
    const res=await fetch(url,{credentials:'same-origin',cache:'no-store',redirect:'follow',signal:controller.signal,headers:{Accept:'text/html,application/xhtml+xml'}});
    if(!res.ok)throw new Error('HTTP '+res.status);
    const html=await res.text();
    const doc=new DOMParser().parseFromString(html,'text/html');
    return {url,items:ppaParseManagerBonuses(doc)};
  }finally{clearTimeout(timer);}
}
async function renderManagerBonuses(root){
  root.dataset.ppaManagerRendered='1';
  ppaApplyContextUI(root);
  const body=root.querySelector('.body');
  body.innerHTML=`<div class="manager-wrap"><div class="bonus-loading"><b>Бонуси від VIP-менеджера</b><br><span>Завантажую бонуси та статистику «Детально»…</span></div></div>`;
  try{
    const {items}=await ppaLoadManagerBonuses();
    if(root.dataset.activeTab!=='bonuses')return;
    let statsHtml='';
    try{
      const stats=await ppaLoadManagerNetStats(items);
      statsHtml=ppaRenderNetStats(stats);
    }catch(statsErr){
      statsHtml=`<div class="manager-alert manager-alert-neutral"><b>Статистика «Детально» недоступна</b><br>${ppaEsc(statsErr?.message||String(statsErr))}</div>`;
    }
    if(root.dataset.activeTab!=='bonuses')return;
    if(!items.length){
      body.innerHTML=`<div class="manager-wrap">${statsHtml}<div class="manager-empty">Бонусів від VIP-менеджера не знайдено.</div></div>`;
      return;
    }
    const cards=items.map(b=>{
      const st=ppaBonusStatus(b.status);
      const grant=b.fs>0?`${b.fs} FS`:ppaFmtBonusMoney(b.bonus);
      const deposit=(b.deposit!==null&&b.deposit>0)?ppaFmtBonusMoney(b.deposit):'Без депозиту';
      const result=b.btr!==null?ppaFmtBonusMoney(b.btr):(b.resultText&&b.resultText!=='n/a'?ppaEsc(b.resultText):'—');
      return `<div class="manager-bonus-card">
        <div class="manager-bonus-top"><div><div class="manager-bonus-date">${ppaEsc(b.date)}</div><div class="manager-bonus-name">${ppaEsc(b.name)}</div></div><span class="bonus-status ${st.cls}">${ppaEsc(st.label)}</span></div>
        <div class="manager-bonus-grid">
          <div><span>Бонус</span><b>${ppaEsc(grant)}</b></div>
          <div><span>Депозит</span><b>${ppaEsc(deposit)}</b></div>
          <div><span>Вейджер</span><b>${ppaEsc(b.wager||'—')}</b></div>
          <div><span>BTR / результат</span><b>${ppaEsc(result)}</b></div>
        </div>
        <div class="manager-bonus-id">ID бонуса: ${ppaEsc(b.id)}</div>
      </div>`;
    }).join('');
    body.innerHTML=`<div class="manager-wrap">
      ${statsHtml}
      <div class="manager-bonus-intro"><div><b>Бонуси від VIP-менеджера</b><span>${items.length} записів</span></div><div class="manager-bonus-note">Історія без оцінок і рекомендацій — тільки фактичні дані з адмінки.</div></div>
      <div class="manager-bonus-list">${cards}</div>
    </div>`;
  }catch(e){
    if(root.dataset.activeTab!=='bonuses')return;
    body.innerHTML=`<div class="manager-wrap"><div class="manager-alert manager-alert-critical"><b>Не вдалося завантажити бонуси</b><br>${ppaEsc(e?.message||String(e))}</div></div>`;
  }
}
function renderManager(root){
  root.dataset.ppaManagerRendered='1';
  ppaApplyContextUI(root);
  const body=root.querySelector('.body');
  const d=ppaReadManagerCard();
  if(!d.manager&&!d.phone&&!d.comments.length){
    body.innerHTML='<div class="manager-empty">На цій сторінці дані VIP-менеджера не знайдені.</div>';
    return;
  }

  const assigned=d.assignment?.hasManager!==false;
  let alert='';
  if(!assigned){
    alert=`<div class="manager-alert manager-alert-neutral"><b>ℹ VIP-менеджер не призначений</b><br>Службовий статус: <b>${ppaEsc(d.assignment.status||d.manager||'—')}</b>.</div>`;
  }else if(d.phoneDetachFlow){
    const source=d.detachComment||d.blockedComment;
    const when=source?.dateText?` від <b>${ppaEsc(source.dateText)}</b>`:'';
    alert=`<div class="manager-alert manager-alert-critical"><b>⚠ Номер потребує підтвердження</b><br>У коментарях менеджера знайдено ознаку відкріплення/блокування номера${when}, а в картці доступне підтвердження телефону.<div class="manager-next"><b>Що передати гравцю:</b><br>1. Повідомити, що номер було відкріплено через тривалу відсутність зв'язку.<br>2. Допомогти підтвердити номер.<br>3. Запропонувати зв'язок з VIP-менеджером.</div></div>`;
  }else if(d.threeFailed){
    alert=`<div class="manager-alert"><b>⚠ Запропонуй зв'язок з VIP-менеджером</b><br>Останні 3 коментарі показують невдалий контакт з гравцем (НВ / АО або аналогічні формулювання).</div>`;
  }else if(d.offerComment){
    alert=`<div class="manager-alert"><b>⚠ Менеджер просить запропонувати зв'язок</b><br>У коментарі є пряма вказівка запропонувати дзвінок або зв'язок з VIP-менеджером.</div>`;
  }else{
    alert=`<div class="manager-alert good"><b>✓ Термінових дій щодо зв'язку не виявлено</b><br>Player Insight перевірив останні коментарі та стан підтвердження телефону.</div>`;
  }

  const cards=d.comments.slice(0,4).map(c=>`
    <div class="manager-comment">
      <div class="manager-comment-head">
        <span><span class="manager-comment-author">${ppaEsc(c.author||'—')}</span>${c.dateText?' · '+ppaEsc(c.dateText):''}</span>
        <span style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end">${assigned&&c.signals.detached?'<span class="manager-status detach">Відкріп номера</span>':''}${assigned&&c.signals.offerManager?'<span class="manager-status action">Запропонувати менеджера</span>':''}<span class="manager-status ${c.contact.kind}">${ppaEsc(c.contact.label)}</span></span>
      </div>
      <div class="manager-comment-text">${ppaEsc(c.text)}</div>
    </div>`).join('');

  body.innerHTML=`<div class="manager-wrap">
    <div class="manager-card">
      <div class="manager-label">Відповідальний VIP-менеджер</div>
      <div class="manager-name">${assigned?ppaEsc(d.manager||'Не вказаний'):'VIP-менеджер не призначений'}</div>
      ${!assigned&&d.assignment.status?`<div class="manager-service-status">Статус: ${ppaEsc(d.assignment.status)}</div>`:''}
      <div class="manager-phone">${assigned?ppaEsc(d.phone||'Номер не вказаний'):'Персональний менеджер відсутній'}</div>
      <div class="manager-actions">
        ${assigned&&d.phone?'<button class="smallbtn manager-copy-phone">📋 Скопіювати номер</button>':''}
      </div>
    </div>
    ${alert}
    <div>
      <div class="manager-label">Останні коментарі VIP-менеджера</div>
      <div class="manager-comments">${cards||'<div class="manager-empty">Коментарів не знайдено.</div>'}</div>
    </div>
  </div>`;

  const copy=body.querySelector('.manager-copy-phone');
  if(copy)copy.onclick=async()=>{
    try{
      await navigator.clipboard.writeText(d.phone);
      setCopiedState(copy,'📋 Номер скопійовано',1300);
    }catch{copy.textContent='Не вдалося скопіювати';}
  };
}

function activateTab(root,tab,r,m,opts={}){
  ppaApplyContextUI(root);
  const ctx=ppaPageContext();
  if(ctx==='manager' && !['manager','bonuses'].includes(tab))tab='manager';
  else if(ctx==='balance' && ['manager','bonuses'].includes(tab))tab='balance';
  const body=root.querySelector('.body');
  root.__ppaScrollByTab=root.__ppaScrollByTab||{};
  const prev=root.dataset.activeTab;
  if(body&&prev)root.__ppaScrollByTab[prev]=body.scrollTop;
  root.dataset.activeTab=tab;

  root.querySelectorAll('.tabbtn').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  if(tab==='manager')renderManager(root);
  else if(tab==='bonuses')renderManagerBonuses(root);
  else if(tab==='games')renderGames(root,r);
  else if(tab==='bets')renderBets(root,r);
  else if(tab==='negative')renderNegative(root,r);
  else renderBalance(root,r,m);
  animateSection(root);
  if(body&&!opts.skipRestore){
    const y=Number(root.__ppaScrollByTab[tab]||0);
    requestAnimationFrame(()=>{body.scrollTop=y;});
  }
}

function setupTabs(root,r,m){
  // Clicks are delegated by shell() in v2.8.2.
  // Keep current analysis context available for balance-related tabs.
  root.__ppaTabResult=r;
  root.__ppaTabMult=m;
}



function ppaShowBalanceNotice(root,text='Аналіз доступний у розділі «Журнал балансу».'){
  document.getElementById('__ppa_notice__')?.remove();
  const n=document.createElement('div');
  n.id='__ppa_notice__';
  n.innerHTML=`<div class="n-title">Player Insight</div><div class="n-text">${text}</div>`;
  document.body.appendChild(n);

  const r=root.getBoundingClientRect();
  const width=270;
  const gap=10;
  let left;
  if(r.left < window.innerWidth/2){
    left=Math.min(window.innerWidth-width-gap,r.right+gap);
  }else{
    left=Math.max(gap,r.left-width-gap);
  }
  const top=Math.max(gap,Math.min(window.innerHeight-70,r.top+4));
  n.style.left=`${left}px`;
  n.style.top=`${top}px`;

  requestAnimationFrame(()=>n.classList.add('show'));
  clearTimeout(window.__ppa_notice_timer__);
  window.__ppa_notice_timer__=setTimeout(()=>{
    n.classList.remove('show');
    setTimeout(()=>n.remove(),230);
  },2600);
}


function ppaIsPlayerCardPage(){
  const tabs=[...document.querySelectorAll('a,button,[role="tab"]')]
    .map(el=>(el.textContent||'').trim().toLowerCase());

  const hasPlayerCardTab=tabs.some(t=>t.includes('картка гравця')||t.includes('карточка игрока'));
  const hasBalanceTab=tabs.some(t=>t.includes('журнал балансу')||t.includes('журнал баланса'));
  const hasPlayerSections=tabs.some(t=>t==='депозити'||t==='депозиты') &&
                          tabs.some(t=>t==='виплати'||t==='выплаты');

  const pageText=document.body?.innerText||'';
  const hasJournalPlayerId=/журнал\s+баланс[ау]\s*#\s*\d+/i.test(pageText);

  const crumbs=[...document.querySelectorAll('.breadcrumb,ol.breadcrumb,.breadcrumbs')];
  const crumbText=crumbs.map(x=>x.textContent||'').join(' ').toLowerCase();
  const hasPlayerBreadcrumb=(crumbText.includes('players')||crumbText.includes('гравці')||crumbText.includes('игроки')) &&
    (crumbText.includes('картка гравця')||crumbText.includes('карточка игрока')||
     crumbText.includes('журнал балансу')||crumbText.includes('журнал баланса'));

  return !!(
    hasJournalPlayerId ||
    hasPlayerBreadcrumb ||
    (hasPlayerCardTab && hasBalanceTab) ||
    (hasPlayerCardTab && hasPlayerSections)
  );
}

function ppaIsBalanceJournal(){
  const tabs=[...document.querySelectorAll('a,button,[role="tab"]')];
  const active=tabs.find(el=>{
    const txt=(el.textContent||'').trim().toLowerCase();
    const cls=String(el.className||'').toLowerCase();
    const aria=el.getAttribute('aria-selected');
    return (cls.includes('active')||aria==='true') &&
      (txt.includes('журнал балансу')||txt.includes('журнал баланса'));
  });
  if(active)return true;
  return !!document.querySelector('tr.input,tr.bet,tr.win,tr.withdrawal_approved');
}
function ppaSyncAdminSection(){
  const root=document.getElementById('__ppa_overlay__');

  if(!ppaIsPlayerCardPage()){
    if(root)root.remove();
    return;
  }

  if(!root){
    ppaBootstrapPersistentDock();
    return;
  }

  if(!ppaIsBalanceJournal() && !ppaHasManagerCardData() && !root.classList.contains('ppa-minimized')){
    const min=root.querySelector('.minbtn');
    if(min)min.click();
  }
  if(!ppaIsBalanceJournal() && ppaHasManagerCardData()){
    ppaApplyContextUI(root);
    if(!root.classList.contains('ppa-minimized') && root.dataset.ppaManagerRendered!=='1'){
      activateTab(root,'manager',window.__ppa_last_result__||{ok:false},2,{skipRestore:true});
    }
  }
}
function ppaInstallAdminWatcher(){
  if(window.__ppa_admin_watcher__)return;
  window.__ppa_admin_watcher__=true;
  document.addEventListener('click',ev=>{
    const nav=ev.target.closest?.('a,button,[role="tab"]');
    if(!nav)return;
    const t=(nav.textContent||'').trim().toLowerCase();
    if(['картка гравця','карточка игрока','депозити','депозиты','виплати','выплаты','журнал балансу','журнал баланса','журнал транзакцій','журнал транзакций','інфо по бонусах'].some(x=>t.includes(x))){
      setTimeout(ppaSyncAdminSection,120);
      setTimeout(ppaSyncAdminSection,450);
    }
  },true);
  const obs=new MutationObserver(()=>{
    clearTimeout(window.__ppa_admin_sync_timer__);
    window.__ppa_admin_sync_timer__=setTimeout(ppaSyncAdminSection,120);
  });
  obs.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','aria-selected']});
  addEventListener('popstate',()=>setTimeout(ppaSyncAdminSection,100));
  addEventListener('hashchange',()=>setTimeout(ppaSyncAdminSection,100));
}
ppaInstallAdminWatcher();

function ppaBootstrapPersistentDock(){
  if(window.__ppa_closed_this_page__)return;

  if(document.getElementById('__ppa_overlay__'))return;
  if(!ppaIsPlayerCardPage())return;

  try{
    localStorage.setItem('__ppa_activated__','1');
    localStorage.setItem('__ppa_minimized__','1');
  }catch{}

  const root=shell();

  requestAnimationFrame(()=>{
    if(!root.classList.contains('ppa-minimized')){
      const min=root.querySelector('.minbtn');
      if(min)min.click();
    }
  });
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',()=>setTimeout(ppaBootstrapPersistentDock,60),{once:true});
}else{
  setTimeout(ppaBootstrapPersistentDock,60);
}

function ppaScheduleBackgroundWarmup(){
  if(window.__ppa_warmup_scheduled__)return;
  window.__ppa_warmup_scheduled__=true;

  const run=()=>{
    if(!ppaIsBalanceJournal())return;
    const root=document.getElementById('__ppa_overlay__');
    if(!root)return;
    root.dataset.period='14';

    // Start silently while the dock is minimized. The collector itself yields
    // every 250 rows and between pages, so Chrome keeps receiving UI time.
    window.__PPA_ANALYZE__?.(2,{background:true,preferCache:true});
  };

  if(typeof requestIdleCallback==='function'){
    requestIdleCallback(()=>setTimeout(run,250),{timeout:1200});
  }else{
    setTimeout(run,700);
  }
}
setTimeout(ppaScheduleBackgroundWarmup,180);



function ppaPlayerCacheKey(){
  const m=location.pathname.match(/\/balanceLog\/(\d+)/i);
  return m?'__ppa_jb14_'+m[1]:null;
}
function ppaLoadSessionCache(){
  const key=ppaPlayerCacheKey(); if(!key)return null;
  try{
    const obj=JSON.parse(sessionStorage.getItem(key)||'null');
    if(!obj?.savedAt||Date.now()-obj.savedAt>5*60*1000)return null;
    obj.rows=(obj.rows||[]).map(r=>({...r,date:new Date(r.date)}))
      .filter(r=>r.date instanceof Date&&!Number.isNaN(r.date.getTime()));
    return obj.rows.length?obj:null;
  }catch{return null;}
}
function ppaSaveSessionCache(obj){
  const key=ppaPlayerCacheKey();
  if(!key||!obj?.rows?.length)return;
  try{sessionStorage.setItem(key,JSON.stringify(obj));}catch{}
}

window.__PPA_ANALYZE__=async(m=2,opts={})=>{
  try{
    m=+m||2;

    // IMPORTANT: never call shell() here. shell() recreates the whole panel,
    // loses dataset.period and caused every period to fall back to 14 days.
    const root=document.getElementById('__ppa_overlay__')||shell();
    const rawPeriod=root.dataset?.period;
    const days=(rawPeriod===undefined||rawPeriod===null||rawPeriod==='') ? 14 : Number(rawPeriod);
    const safeDays=[0,3,7,14].includes(days)?days:14;
    root.dataset.period=String(safeDays);

    let collected=null;
    if(!window.__ppa_jb_cache__){
      const persisted=ppaLoadSessionCache();
      if(persisted)window.__ppa_jb_cache__=persisted;
    }
    const cache=window.__ppa_jb_cache__;

    // Any cached wider period can answer a shorter period immediately.
    if(cache?.rows?.length && Number(cache.coverageDays)>=safeDays){
      collected={
        rows:cache.rows,
        pages:cache.pages||1,
        totalPages:cache.totalPages||1,
        complete:true,
        error:null,
        diagnostics:cache.diagnostics||[]
      };
    }else{
      // Only ONE multipage scan may exist at a time.
      // Opening the panel while warm-up is running simply awaits the same scan.
      if(window.__ppa_collect_promise__ && Number(window.__ppa_collect_days__||-1)>=safeDays){
        collected=await window.__ppa_collect_promise__;
      }else{
        window.__ppa_collect_days__=safeDays;
        window.__ppa_collect_promise__=ppaCollectJournalDays(safeDays);
        try{
          collected=await window.__ppa_collect_promise__;
        }finally{
          window.__ppa_collect_promise__=null;
          window.__ppa_collect_days__=-1;
        }
      }

      if(collected?.rows?.length){
        const prev=window.__ppa_jb_cache__;
        if(!prev || safeDays>=Number(prev.coverageDays||-1)){
          window.__ppa_jb_cache__={
            rows:collected.rows,
            pages:collected.pages||1,
            totalPages:collected.totalPages||1,
            diagnostics:collected.diagnostics||[],
            coverageDays:safeDays,
            savedAt:Date.now()
          };
          ppaSaveSessionCache(window.__ppa_jb_cache__);
        }
      }
    }

    const filtered=ppaFilterRowsToPeriod(collected.rows,safeDays);
    await ppaYield();
    const r=analyze(m,filtered.rows);
    await ppaYield();
    if(r.ok){
      r.periodStart=filtered.start;
      r.periodEnd=filtered.end;
      r.mult=m;
      r.journalPages=collected.pages||1;
      r.journalTotalPages=collected.totalPages||1;
      r.journalComplete=!!collected.complete;
      r.journalFetchError=collected.error||null;
      r.journalDiagnostics=collected.diagnostics||[];
      r.incomplete=!collected.complete;
      window.__ppa_last_result__=r;
      try{localStorage.setItem('__ppa_activated__','1')}catch{}
      renderBalance(root,r,m);
      setupTabs(root,r,m);
      if(!root.classList.contains('ppa-minimized'))animateSection(root);
    }
    return{ok:r.ok,error:collected.error||r.error||null,count:r.count||0,pages:collected.pages||1,totalPages:collected.totalPages||1,complete:!!collected.complete};
  }catch(e){
    console.error('[Player Insight][ANALYZE]',e);
    return{ok:false,error:e?.message||String(e),count:0};
  }
};})();

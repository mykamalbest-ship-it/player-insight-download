
const button=document.getElementById('analyze');
const status=document.getElementById('status');
button.addEventListener('click',async()=>{
  button.disabled=true; status.className=''; status.textContent='Читаю сторінки ЖБ за 14 днів...';
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id) throw new Error('Не вдалося визначити активну вкладку.');
    // content.js is now loaded automatically by manifest content_scripts.
    // Keep a fallback injection for already-open tabs right after extension reload.
    let loaded = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:()=>typeof window.__PPA_ANALYZE__==='function'
    });
    if(!loaded?.[0]?.result){
      await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});
    }
    const [{result}]=await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:async()=>window.__PPA_ANALYZE__?await window.__PPA_ANALYZE__(2):{ok:false,error:'Analyzer not loaded'}
    });
    if(!result?.ok) throw new Error(result?.error||'Невідома помилка');
    if(result.error){
        status.className='err'; status.textContent=`⚠ ${result.error}`;
      }else{
        status.className='ok'; status.textContent=`✓ Готово. ЖБ: ${result.pages||1} стор. · x2+: ${result.count}`;
      }
    setTimeout(()=>window.close(),180);
  }catch(e){status.className='err'; status.textContent='Відкрийте Журнал балансу та спробуйте ще раз.'}
  finally{button.disabled=false}
});

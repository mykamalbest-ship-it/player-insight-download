# Player Insight v2.8.2

Исправлен клик по вкладке «🎁 Бонуси» на карточке игрока.

Причина v2.8.1:
вкладки стали видимыми, но обработчики клика назначались функцией `setupTabs()`.
На карточке игрока анализ ЖБ не запускается, поэтому `setupTabs()` в этом сценарии мог вообще не вызваться.

Исправление:
- обработка вкладок перенесена на делегированный click-handler самого окна Player Insight;
- «Менеджер» и «🎁 Бонуси» работают независимо от запуска анализа ЖБ;
- старый `setupTabs()` больше не создаёт дублирующиеся onclick;
- логика вкладок ЖБ сохранена.


## v3.0.2
- Fixed player identity: `/players/playersItems/update/<ID>/` is treated as internal ID, not Login.
- `PlayersDetailForm[login]` is read from the explicit Login field on the player card.
- Kept the v2.9.9 native same-origin POST flow separately for 777 and Vegas.


## v3.0.2
- Real player Login is read from the copy marker `data-for-copy` on the player card.
- Supports the same markup on admin.777.ua and admin.vegas.ua.
- The internal `/playersItems/update/<ID>/` value is never used as PlayersDetailForm[login].


## v3.0.4
- Любой назначенный бездепозитный бонус текущего месяца учитывается независимо от статуса (done/rejected/canceled/expired).
- После бездепа период «Детально» начинается со следующего календарного дня, порог — 10 000 грн.
- Если бездеп назначен сегодня, запрос с обратным периодом не отправляется: показывается ожидание следующего дня.
- Если бездепов в текущем месяце нет, расчёт остаётся с 1-го числа и порогом 5 000 грн.


## v3.0.6
- 777: `club-millionaires` remains the compact jackpot activity card in Ігри.
- Vegas: `vegas-heist` is shown the same way, with only bet count and wagered amount.
- Special activity is pinned above normal games and excluded from top-game share/ranking.
- Header polished: original icon preserved with fixed aspect ratio; tabs have stable sizing, hover space and active state.
